<?php
//000000000001{"auto_confirm_date":"3","freight_free":"1000","point_rate":"1","auto_service_date":"15","reduce":"1","form_submit":"ok","point_min_limit":"0","point_use_percent":"50","integral_use_enable":"1"}
?>