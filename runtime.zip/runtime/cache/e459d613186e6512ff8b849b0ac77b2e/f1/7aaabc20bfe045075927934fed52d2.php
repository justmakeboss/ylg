<?php
//000000000001{"reg_integral":"100","file_size":"1","default_storage":"1","warning_storage":"1","tax":"6","is_remind":"0","order_finish_time":"","order_cancel_time":"","hot_keywords":"\u624b\u673a|\u5c0f\u7c73|iphone|\u4e09\u661f|\u534e\u4e3a|\u51b0\u7bb1","app_test":"0","need":"1","min":"1","invite":"1","is_bind_account":"1","prepaid_price":"30","verify_switch":"0"}
?>