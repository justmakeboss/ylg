<?php
//000000086400{"code":"shentong","name":"\u7533\u901a\u7269\u6d41","version":"1.0","author":"\u5b87\u5b99\u4eba","config":"N;","config_value":null,"desc":"\u7533\u901a\u7269\u6d41\u63d2\u4ef6 ","status":1,"type":"shipping","icon":"logo.jpg","bank_code":"N;","scene":null}
?>