<?php
//000000000001{"is_buy_appoint_product_enable":"0","buy_any":"0","one_consumption":"0","all_consumption":"0","cumulative_purchases":"0"}
?>