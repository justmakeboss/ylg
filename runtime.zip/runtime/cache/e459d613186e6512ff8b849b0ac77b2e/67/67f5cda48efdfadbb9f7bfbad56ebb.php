<?php
//000000000001{"funds":"21","pattern":"1","commission":"0","clearing":"0","date":"0","freight":"0","lines":"0","poundage":"","interval_start":"","interval_end":"","prize_begin_time":"1534003200","share_price":"196"}
?>