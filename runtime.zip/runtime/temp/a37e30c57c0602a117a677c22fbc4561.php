<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:37:"./template/mobile/new/user\login.html";i:1551506979;s:39:"./template/mobile/new/common\block.html";i:1551506935;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=0">
    <link rel="stylesheet" type="text/css" href="__STATIC__/assets/weui/weui.css">
    <link rel="stylesheet" type="text/css" href="__STATIC__/assets/css/comm.css">
    <link rel="stylesheet" type="text/css" href="__STATIC__/assets/css/index.css">
    <link rel="stylesheet" type="text/css" href="__STATIC__/assets/js/lib/Swiper-3.4.2/swiper.min.css">
    <link rel="stylesheet" type="text/css" href="__STATIC__/assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="__STATIC__/assets/css/category.css">
    <script src="__STATIC__/assets/js/lib/jquery.min.2.1.3.js"></script>
    <script src="__STATIC__/assets/js/lib/weui.min.js"></script>
    <script src="__STATIC__/assets/js/comm.js"></script>

    <script src="__PUBLIC__/js/global.js"></script>
    <script src="__STATIC__/js/layer.js"  type="text/javascript" ></script>

    <title>登录</title>
    
    <style>
        .hd_icon {
            width: 0.6rem;
            margin-right: 6px;
        }

        .eye {
            display: inline-block;
            width: 0.6rem;
            height: 0.6rem;
            background-size: 100%;
            position: relative;
            top: 0.2rem;
        }

        .eye.open {
            background-image: url(__STATIC__/assets/images/eye-open.png);
        }

        .eye.close {
            background-image: url(__STATIC__/assets/images/eye-close.png);
        }
        .other-type{
            position: absolute;
            left: 15px;
            right: 15px;
            bottom: 30px;
        }
        .other-type img{
            width: 1.3rem;
            height: 1.3rem;
        }

        .login_type{
            display: inline-block;
            width:1.834666rem;
            height:1.834666rem;
            margin: 0 .64rem;
            background-image: url("__STATIC__/images/ico- third-party.png");
            background-repeat: no-repeat;
            background-size: 5.504rem 1.834666rem;
        }
        .ico-wechat-login{
            background-position: 0 0;
        }
        .ico-qq-login{
            background-position:-1.834666rem 0;
        }
        .ico-alipay-login{
            background-position:-3.669332rem 0;
        }
    </style>

</head>

<body>
    <div class="page">
        <div class="page-hd">
            <div class="header">
                <div class="header-left">
                    <a href="javascript:history.back(-1);" class="left-arrow"></a>
                </div>
                <div class="header-title">登录</div>
                <div class="header-right"><a href="#"></a> </div>
            </div>
        </div>
        

        <div class="page-bd" style="background-color: #fff;">
            <form  id="loginform" method="post"  >
            <div class="vux-1px-t"></div>
            <div class="weui-cells vux-1px-b weui-cells_form" style="margin-left: 15px; margin-right:15px;">
                <div class="weui-cell after-left__0">
                    <div class="weui-cell__hd"><img class="hd_icon" src="__STATIC__/assets/images/icon_iphone.png" alt=""></div>
                    <div class="weui-cell__bd">
                        <input class="weui-input" name="username" id="username" value=""  placeholder="请输入用户名">
                    </div>
                    <div class="weui-cell__ft"></div>
                </div>
                <div class="weui-cell after-left__0">
                    <div class="weui-cell__hd"><img class="hd_icon" src="__STATIC__/assets/images/icon_lock.png" alt=""></div>
                    <div class="weui-cell__bd">
                        <input class="weui-input" type="password" name="password" id="password" value="" placeholder="请输入密码">
                    </div>
                    <div class="weui-cell__ft">
                        <i class="eye open close"></i>
                    </div>
                </div>
            </div>
            <div class="weui-btn-area">
                <a href="javascript:void(0)" onclick="submitverify()"  class="weui-btn weui-btn_primary">登录</a>
                <div class="weui-flex mt10 fs10">
                    <div class="weui-flex__item"><a href="<?php echo U('User/reg'); ?>" class="text-muted">我要注册</a></div>
                    <div><a href="<?php echo U('User/forget_pwd'); ?>" class="text-muted">忘记密码?</a></div>
                </div>
            </div>

            <div class="other-type" style="text-align: center; display: none">
                <!--<div class="divder">其他登录方式</div>-->
                <!--<div>-->
                    <!--<?php
                                   
                                $md5_key = md5("select * from __PREFIX__plugin where type='login' AND status = 1");
                                $result_name = $sql_result_v = S("sql_".$md5_key);
                                if(empty($sql_result_v))
                                {                            
                                    $result_name = $sql_result_v = \think\Db::query("select * from __PREFIX__plugin where type='login' AND status = 1"); 
                                    S("sql_".$md5_key,$sql_result_v,86400);
                                }    
                              foreach($sql_result_v as $k=>$v): ?>-->
                        <!--<?php if($v['code'] == 'qq' AND is_qq() != 1): ?>-->
                            <!--<a class="login_type login_type ico-qq-login" href="<?php echo U('LoginApi/login',array('oauth'=>'qq')); ?>"></a>-->
                        <!--<?php endif; ?>-->
                        <!--<?php if($v['code'] == 'alipay' AND is_alipay() != 1): ?>-->
                            <!--<a class="login_type ico-alipay-login" href="<?php echo U('LoginApi/login',array('oauth'=>'alipay')); ?>"></a>-->
                        <!--<?php endif; ?>-->
                    <!--<?php endforeach; ?>-->
                <!--</div>-->
            </div>

            </form>
        </div>

    </div>
    
    <script type="text/javascript">
        $(function () {
            $('.eye').on('click', function (e) {
                $(this).toggleClass('close');
                if ($('#password').attr('type') == 'password') {
                    $('#password').attr('type', 'text');
                } else {
                    $('#password').attr('type', 'password');
                }

            });
        });
        function verify(){
            $('#verify_code_img').attr('src','/index.php?m=Mobile&c=User&a=verify&r='+Math.random());
        }

        //复选框状态
        function remember(obj){
            var che= $(obj).attr("class");
            if(che == 'che check_t'){
                $("#autologin").prop('checked',false);
            }else{
                $("#autologin").prop('checked',true);
            }
        }
        function submitverify()
        {
            var username = $.trim($('#username').val());
            var password = $.trim($('#password').val());
            var remember = $('#remember').val();
            var referurl = $('#referurl').val();
            var verify_code = $.trim($('#verify_code').val());
            if(username == ''){
                showErrorMsg('用户名不能为空!');
                return false;
            }
            if(!checkMobile(username) && !checkEmail(username)){
                showErrorMsg('账号格式不匹配!');
                return false;
            }
            if(password == ''){
                showErrorMsg('密码不能为空!');
                return false;
            }
            var codeExist = $('#verify_code').length;
            if (codeExist && verify_code == ''){
                showErrorMsg('验证码不能为空!');
                return false;
            }

            var data = {username:username,password:password,referurl:referurl};
            if (codeExist) {
                data.verify_code = verify_code;
            }
            $.ajax({
                type : 'post',
                url : '/index.php?m=Mobile&c=User&a=do_login&t='+Math.random(),
                data : data,
                dataType : 'json',
                success : function(data){
                    if(data.status == 1){
                        var url = data.url.toLowerCase();
                        if (url.indexOf('user') !=  false && url.indexOf('login') != false || url == '') {
                            window.location.href = '/index.php/mobile';
                        }else{
                            window.location.href = data.url;
                        }
                    }else{
                        showErrorMsg(data.msg);
                        /*if (codeExist) {
                            verify();
                        } else {
                            location.reload();
                        }*/
                    }
                },
                error : function(XMLHttpRequest, textStatus, errorThrown) {
                    showErrorMsg('网络异常，请稍后重试');
                }
            })
        }
    </script>


</body>
</html>

