<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:44:"./template/mobile/new/goods\ajaxComment.html";i:1551506935;}*/ ?>
<?php if($count > 0): if(is_array($commentlist) || $commentlist instanceof \think\Collection || $commentlist instanceof \think\Paginator): if( count($commentlist)==0 ) : echo "" ;else: foreach($commentlist as $k=>$v): ?>
    <div class="weui-cells">
        <div class="weui-cell">
            <div class="weui-cell__hd">
                <img class="avatar" src="<?php echo (isset($v['head_pic']) && ($v['head_pic'] !== '')?$v['head_pic']:'__STATIC__/images/user68.jpg'); ?>" alt="">
            </div>
            <div class="weui-cell__bd">
                <?php if($v['is_anonymous'] == 1): ?>
                <div class="text-muted">匿名用户</div>
                <?php else: ?>
                <div class="text-muted"><?php echo $v['username']; ?></div>
                <?php endif; ?>
                <!--<div class="text-muted">粉紫色-M</div>-->
            </div>
            <div class="weui-cell__ft fs8 "><span class="text-muted"><?php echo date('Y-m-d H:i',$v['add_time']); ?></span></div>
        </div>
        <div class="weui-cell vcenter">
            <span class="text-muted">商品评分</span>

                                    <span class="starts">
                                        <?php echo $v['service_rank']; ?>
                                        <!--<img src="__STATIC__/assets/images/start1.png" alt="">-->
                                        <!--<img src="__STATIC__/assets/images/start1.png" alt="">-->
                                        <!--<img src="__STATIC__/assets/images/start1.png" alt="">-->
                                        <!--<img src="__STATIC__/assets/images/start1.png" alt="">-->
                                        <!--<img src="__STATIC__/assets/images/start2.png" alt="">-->
                                    </span>
        </div>
        <div class="weui-cell"><?php echo htmlspecialchars_decode($v['content']); ?></div>
        <div class="weui-cell proimgs">
            <ul class="jd-slider-container gallery">
                <?php if(is_array($v['img']) || $v['img'] instanceof \think\Collection || $v['img'] instanceof \think\Paginator): if( count($v['img'])==0 ) : echo "" ;else: foreach($v['img'] as $key=>$v2): ?>
                    <li class="proimg">
                        <dd><a href="<?php echo $v2; ?>"><img src="<?php echo $v2; ?>" width="100px" heigth="100px"></a></dd>
                    </li>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
            <!--<span class="proimg" style="background-image: url(__STATIC__/assets/images/proimg.jpg)"></span>-->
            <!--<span class="proimg" style="background-image: url(__STATIC__/assets/images/proimg.jpg)"></span>-->
            <!--<span class="proimg" style="background-image: url(__STATIC__/assets/images/proimg.jpg)"></span>-->
        </div>
        <div class="weui-cell">
            <?php if(is_array($replyList[$v['comment_id']]) || $replyList[$v['comment_id']] instanceof \think\Collection || $replyList[$v['comment_id']] instanceof \think\Paginator): if( count($replyList[$v['comment_id']])==0 ) : echo "" ;else: foreach($replyList[$v['comment_id']] as $k=>$reply): ?>
            <div class="yhzbox text-muted"><?php echo $reply['username']; ?>回复：<?php echo $reply['content']; ?></div>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </div>
    </div>
    <?php endforeach; endif; else: echo "" ;endif; else: ?>
    <script>
        $('.getmore').hide();
    </script>
    <!--没有内容时-s-->
    <div class="comment_con p">
        <div class="score enkecor">此商品暂无评论</div>
    </div>
    <!--没有内容时-e-->
<?php endif; if(($count > $current_count) AND (count($commentlist) == $page_count)): ?>
    <div class="getmore" style="font-size:.32rem;text-align:center;color:#888;padding:.25rem .24rem .4rem; clear:both">
        <a href="javascript:void(0)" onClick="ajaxSourchSubmit();">点击加载更多</a>
    </div>
    <?php elseif(($count <= $current_count AND $count > 0)): ?>
    <div class="score enkecor">已显示完所有评论</div>
    <?php else: endif; ?>


<link href="__STATIC__/css/photoswipe.css" rel="stylesheet" type="text/css">
<script src="__STATIC__/js/klass.min.js"></script>
<script src="__STATIC__/js/photoswipe.js"></script>
<script type="text/javascript">
    $(document).ready(function () {
        var gallery_a = $(".gallery a");
        if(gallery_a.length > 0){
            $(".gallery a").photoSwipe({
                enableMouseWheel: false,
                enableKeyboard: false,
                allowUserZoom: false,
                loop:false
            });
        }
    });
     var page = <?php echo \think\Request::instance()->param('p'); ?>;
     function ajaxSourchSubmit() {
         page += 1;
         $.ajax({
             type: "GET",
             url: "<?php echo U('Mobile/Goods/ajaxComment',array('goods_id'=>$goods_id,'commentType'=>$commentType),''); ?>"+"/p/" + page,
             success: function (data) {
                 $('.getmore').hide();
                 if ($.trim(data) != ''){
                     $(".comments").append(data);
                 }
             }
         });
     }
     function ajax_sourch_submit_hide(){
         $('.getmore').hide();
     }

     //点赞
     function hde(){
         setTimeout(function(){
             $('.alert').hide();
         },1200)
     }

 </script>