<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:47:"./application/admin/view2/user\_user\level.html";i:1551594231;s:44:"./application/admin/view2/public\layout.html";i:1551506736;}*/ ?>
<!doctype html>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<!-- Apple devices fullscreen -->
<meta name="apple-mobile-web-app-capable" content="yes">
<!-- Apple devices fullscreen -->
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<link href="__PUBLIC__/static/css/main.css" rel="stylesheet" type="text/css">
<link href="__PUBLIC__/static/css/page.css" rel="stylesheet" type="text/css">
<link href="__PUBLIC__/static/font/css/font-awesome.min.css" rel="stylesheet" />
<!--[if IE 7]>
  <link rel="stylesheet" href="__PUBLIC__/static/font/css/font-awesome-ie7.min.css">
<![endif]-->
<link href="__PUBLIC__/static/js/jquery-ui/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
<link href="__PUBLIC__/static/js/perfect-scrollbar.min.css" rel="stylesheet" type="text/css"/>
<style type="text/css">html, body { overflow: visible;}</style>
<script type="text/javascript" src="__PUBLIC__/static/js/jquery.js"></script>
<script type="text/javascript" src="__PUBLIC__/static/js/jquery-ui/jquery-ui.min.js"></script>
<script type="text/javascript" src="__PUBLIC__/static/js/layer/layer.js"></script><!-- 弹窗js 参考文档 http://layer.layui.com/-->
<script type="text/javascript" src="__PUBLIC__/static/js/admin.js"></script>
<script type="text/javascript" src="__PUBLIC__/static/js/jquery.validation.min.js"></script>
<script type="text/javascript" src="__PUBLIC__/static/js/common.js"></script>
<script type="text/javascript" src="__PUBLIC__/static/js/perfect-scrollbar.min.js"></script>
<script type="text/javascript" src="__PUBLIC__/static/js/jquery.mousewheel.js"></script>
<script src="__PUBLIC__/js/myFormValidate.js"></script>
<script src="__PUBLIC__/js/myAjax2.js"></script>
<script src="__PUBLIC__/js/global.js"></script>
    <script type="text/javascript">
    function delfunc(obj){
    	layer.confirm('确认删除？', {
    		  btn: ['确定','取消'] //按钮
    		}, function(){
    		    // 确定
   				$.ajax({
   					type : 'post',
   					url : $(obj).attr('data-url'),
   					data : {act:'del',del_id:$(obj).attr('data-id')},
   					dataType : 'json',
   					success : function(data){
						layer.closeAll();
   						if(data==1){
   							layer.msg('操作成功', {icon: 1});
   							$(obj).parent().parent().parent().remove();
   						}else{
   							layer.msg(data, {icon: 2,time: 2000});
   						}
   					}
   				})
    		}, function(index){
    			layer.close(index);
    			return false;// 取消
    		}
    	);
    }

    function selectAll(name,obj){
    	$('input[name*='+name+']').prop('checked', $(obj).checked);
    }

    function get_help(obj){

		window.open("http://www.tp-shop.cn/");
		return false;

        layer.open({
            type: 2,
            title: '帮助手册',
            shadeClose: true,
            shade: 0.3,
            area: ['70%', '80%'],
            content: $(obj).attr('data-url'),
        });
    }

    function delAll(obj,name){
    	var a = [];
    	$('input[name*='+name+']').each(function(i,o){
    		if($(o).is(':checked')){
    			a.push($(o).val());
    		}
    	})
    	if(a.length == 0){
    		layer.alert('请选择删除项', {icon: 2});
    		return;
    	}
    	layer.confirm('确认删除？', {btn: ['确定','取消'] }, function(){
    			$.ajax({
    				type : 'get',
    				url : $(obj).attr('data-url'),
    				data : {act:'del',del_id:a},
    				dataType : 'json',
    				success : function(data){
						layer.closeAll();
    					if(data == 1){
    						layer.msg('操作成功', {icon: 1});
    						$('input[name*='+name+']').each(function(i,o){
    							if($(o).is(':checked')){
    								$(o).parent().parent().remove();
    							}
    						})
    					}else{
    						layer.msg(data, {icon: 2,time: 2000});
    					}
    				}
    			})
    		}, function(index){
    			layer.close(index);
    			return false;// 取消
    		}
    	);
    }

    /**
     * 全选
     * @param obj
     */
    function checkAllSign(obj){
        $(obj).toggleClass('trSelected');
        if($(obj).hasClass('trSelected')){
            $('#flexigrid > table>tbody >tr').addClass('trSelected');
        }else{
            $('#flexigrid > table>tbody >tr').removeClass('trSelected');
        }
    }
    /**
     * 批量公共操作（删，改）
     * @returns {boolean}
     */
    function publicHandleAll(type){
        var ids = '';
        $('#flexigrid .trSelected').each(function(i,o){
//            ids.push($(o).data('id'));
            ids += $(o).data('id')+',';
        });

        if(ids == ''){
            layer.msg('至少选择一项', {icon: 2, time: 2000});
            return false;
        }
        publicHandle(ids,type); //调用删除函数
    }
    /**
     * 公共操作（删，改）
     * @param type
     * @returns {boolean}
     */
    function publicHandle(ids,handle_type){
        layer.confirm('确认当前操作？', {
                    btn: ['确定', '取消'] //按钮
                }, function () {
                    // 确定
                    $.ajax({
                        url: $('#flexigrid').data('url'),
                        type:'post',
                        data:{ids:ids,type:handle_type},
                        dataType:'JSON',
                        success: function (data) {
                            layer.closeAll();
                            if (data.status == 1){
                                layer.msg(data.msg, {icon: 1, time: 2000},function(){
                                    location.href = data.url;
                                });
                            }else{
                                layer.msg(data.msg, {icon: 2, time: 2000});
                            }
                        }
                    });
                }, function (index) {
                    layer.close(index);
                }
        );
    }
</script>  

</head>
<style>
    .tab-content , .tab-content2{
        display: none;
        height: 350px;
        overflow:auto;
    }
    .btn{
        display: inline-block;
        background: #00a0e9;
        color:#FFFFFF;
        border-radius: 5px;
        padding: 5px;
        margin-left: 5px;
        cursor: default;
    }
</style>
<body style="background-color: #FFF; overflow: auto;">
<div id="toolTipLayer" style="position: absolute; z-index: 9999; display: none; visibility: visible; left: 95px; top: 573px;"></div>
<div id="append_parent"></div>
<div id="ajaxwaitid"></div>
<div class="page">
    <div class="fixed-bar">
        <div class="item-title"><a class="back" href="javascript:history.back();" title="返回列表"><i class="fa fa-arrow-circle-o-left"></i></a>
            <div class="subject">
                <h3>会员等级管理 - 编辑会员等级</h3>
                <h5>网站系统会员等级管理</h5>
            </div>
        </div>
    </div>
    <form class="form-horizontal" id="handleposition" method="post">
        <input type="hidden" name="act" value="<?php echo $act; ?>">
        <input type="hidden" name="level_id" value="<?php echo $info['level_id']; ?>">
        <div class="ncap-form-default">
            <dl class="row">
                <dt class="tit">
                    <label for="level_name"><em>*</em>等级名称</label>
                </dt>
                <dd class="opt">
                    <input type="text" name="level_name" value="<?php echo $info['level_name']; ?>" id="level_name" class="input-txt">
                    <span class="err" id="err_level_name"></span>
                    <p class="notic">设置会员等级名称</p>
                </dd>
            </dl>
            <dl class="row">
                <?php if(true):?>
                <dt class="tit">
                    <label for="level_name"><em>*</em>累计订单金额（元）</label>
                </dt>
                
                <dd class="opt">
                    <input type="text" name="amount" value="<?php echo $info['amount']; ?>" id="level_name" class="input-txt">
                    <span class="err" id="err_level_name"></span>
                    <p class="notic">设置累计订单金额（元）</p>
                </dd>
                <?php else:?>
                <dt class="tit">
                    <label for="level_name"><em>*</em>购买活动区次数</label>
                </dt>
                <dd class="opt">
                    <input type="text" name="amount" value="<?php echo $info['amount']; ?>" id="level_name" class="input-txt">
                    <span class="err" id="err_level_name"></span>
                    <p class="notic">每月购买</p>
                </dd>
                <?php endif;?>

            </dl>
            <?php if(false):?>
            <dl class="row">
                <dt class="tit">
                    <label for="level_name"><em>*</em>团队达到</label>
                </dt>
                <dd class="opt">
                    <input type="text" name="team" value="<?php echo $info['team']; ?>" id="level_name" class="input-txt">
                    <span class="err" id="err_level_name"></span>
                    <p class="notic">人</p>
                </dd>


            </dl>
            <?php endif;?>
            <dl class="row">
                <dt class="tit">
                    <label for="level_name"><em>*</em>直推消费商（个）</label>
                </dt>
                <dd class="opt">
                    <input type="text" name="discount" value="<?php echo $info['discount']; ?>" id="level_name" class="input-txt">
                    <span class="err" id="err_level_name"></span>
                    <p class="notic">设置直推消费商（个）</p>
                </dd>
            </dl>
            <dl class="row">
                <dt class="tit">
                    <label for="level_name"><em>*</em>直推代理商（个）</label>
                </dt>
                <dd class="opt">
                    <input type="text" name="region_code" value="<?php echo $info['region_code']; ?>" id="level_name" class="input-txt">
                    <span class="err" id="err_level_name"></span>
                    <p class="notic">设置直推代理商（个）</p>
                </dd>
            </dl>
            <dl class="row">
                <dt class="tit">
                    <label for="level_name"><em>*</em>一个消费商不低于（元）</label>
                </dt>
                <dd class="opt">
                    <input type="text" name="is_promote" value="<?php echo $info['is_promote']; ?>" id="level_name" class="input-txt">
                    <span class="err" id="err_level_name"></span>
                    <p class="notic">其中一个消费商自然月不低于（）元</p>
                </dd>
            </dl>
            <dl class="row">
                <dt class="tit">
                    <label for="level_name"><em>*</em>其他所有消费商不低于（元）</label>
                </dt>
                <dd class="opt">
                    <input type="text" name="is_region_agent" value="<?php echo $info['is_region_agent']; ?>" id="level_name" class="input-txt">
                    <span class="err" id="err_level_name"></span>
                    <p class="notic">其他所有消费商的总和业绩不低于（）元</p>
                </dd>
            </dl>
            <!-- <dl class="row">
                <dt class="tit">
                    <label for="level_name"><em>*</em>总的下级不低于（个）</label>
                </dt>
                <dd class="opt">
                    <input type="text" name="region_code" value="<?php echo $info['region_code']; ?>" id="level_name" class="input-txt">
                    <span class="err" id="err_level_name"></span>
                    <p class="notic">设置总的下级不低于（个）</p>
                </dd>
            </dl> -->
            <dl class="row">
                <dt class="tit">
                    等级描述
                </dt>
                <dd class="opt">
                    <textarea  name="describe" class="tarea" rows="6"><?php echo $info['describe']; ?></textarea>
                    <span class="err" id="err_describe"></span>
                    <p class="notic">会员等级描述信息</p>
                </dd>
            </dl>
            <div class="bot">
                <a href="JavaScript:void(0);" onclick="verifyForm()" class="ncap-btn-big ncap-btn-green" id="submitBtn">确认提交</a>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript">
    function verifyForm(){
        $('span.err').show();
        $.ajax({
            type: "POST",
            url: "<?php echo U('Admin/User.User/levelHandle'); ?>",
            data: $('#handleposition').serialize(),
            dataType: "json",
            error: function () {
                layer.alert("服务器繁忙, 请联系管理员!");
            },
            success: function (data) {
                if (data.status == 1) {
                    layer.msg(data.msg, {icon: 1});
                    //location.href = "<?php echo U('Admin/Distribut.Distribut/index',['inc_type'=>'role_info']); ?>";
                    location.href = "<?php echo U('Admin/User.User/levelList'); ?>";
                } else {
                    layer.msg(data.msg, {icon: 2});
                    $.each(data.result, function (index, item) {
                        $('#err_' + index).text(item).show();
                    });
                }
            }
        });
    }
    //改变达成条件显示/隐藏状态
    function alter_condition(status){
        if(status == 'show'){
            $('#alter_condition').show();
            $('#alter_condition_button').hide();
            $('input[name="IsQualificationTab2"]').val('1');//使用条件二
        }else if(status == 'hide'){
            $('#alter_condition').hide();
            $('#alter_condition_button').show();
            $('input[name="IsQualificationTab2"]').val('0');//不使用条件二
        }
    }
    //改变角色条件的tab
    function alter_qualification_tab(that,cid){
        $($(that).siblings().find('a')).removeClass('current');
        $(that).find('a').addClass('current');
        $('.tab-content').hide();
        var tab_content_id = '#tab-content-'+cid;
        $(tab_content_id).show();
    }
    //改变角色条件2的tab
    function alter_qualification_tab2(that,cid){
        $($(that).siblings().find('a')).removeClass('current');
        $(that).find('a').addClass('current');
        $('.tab-content2').hide();
        var tab_content_id = '#tab-content2-'+cid;
        $(tab_content_id).show();
    }
    //添加金额条件
    function add_accumulative_currency(that,type){
        var add_html = '';
        if(type){
            add_html = $('.add_accumulative_currency'+type).html();
        }else{
            add_html = $('.add_accumulative_currency').html();
        }
        var del_button = '<span><a onclick="del_accumulative_currency(this);" style="color: red; text-decoration: underline;">删除</a></span>';
        $(that).parent().append('<div><div class="clear"></div>'+add_html+del_button+'</div>');
    }
    //删除金额条件
    function del_accumulative_currency(that){
        $(that).parent().parent().remove();
    }
    //添加直推条件
    function add_direct_grade(that,type){
        var add_html = '';
        if(type){
            add_html = $('.add_direct_grade'+type).html();
        }else{
            add_html = $('.add_direct_grade').html();
        }
        var del_button = '<span><a onclick="del_direct_grade(this);" style="color: red; text-decoration: underline;">删除</a></span>';
        $(that).parent().append('<div><div class="clear"></div>'+add_html+del_button+'</div>');
    }
    //删除直推条件
    function del_direct_grade(that){
        $(that).parent().parent().remove();
    }
    //添加推荐层条件
    function add_recommend_level(that,type){
        var add_html = '';
        if(type){
            add_html = $('.add_recommend_level'+type).html();
        }else{
            add_html = $('.add_recommend_level').html();
        }
        var del_button = '<span><a onclick="del_recommend_level(this);" style="color: red; text-decoration: underline;">删除</a></span>';
        $(that).parent().append('<div><div class="clear"></div>'+add_html+del_button+'</div>');
    }
    //删除推荐层条件
    function del_recommend_level(that){
        $(that).parent().parent().remove();
    }
    //将点击的商品类别添加到显示中
    function input_appoint(that,type){
        //获取商品类别信息
        var identity_id = $(that).val();//商品类别id
        if(identity_id == 0)return;
        var identity_name = $(that).find('option:selected').text();//商品类别名称
        //数据初始化
        var show_appoint = '';//显示的数据
        var hide_appoint = '';//隐藏提交的数据
        var is_repeat = false;//是否重复
        //页面显示
        if(type == 1){
            show_appoint = $('#show_appoint');
            hide_appoint = $('#hide_appoint');
        }else{
            show_appoint = $('#show_appoint2');
            hide_appoint = $('#hide_appoint2');
        }
        //当前值
        var appoint_hide_now = hide_appoint.val();
        if(appoint_hide_now != '' && appoint_hide_now != 0 && appoint_hide_now != '0'){
            var appoint_arr = appoint_hide_now.split(',');
            //检查重复
            for(var i=0;i<appoint_arr.length;i++){
                if(appoint_arr[i] == identity_id){
                    is_repeat = true;break;
                }
            }
            if(is_repeat == false){
                //插入新的商品分类id
                appoint_arr.push(identity_id);
                var temp = appoint_arr.join(",");
                hide_appoint.val(temp);
            }
        }else{
            hide_appoint.val(identity_id);
        }
        //插入新的button
        if(is_repeat == false){
            //插入的button
            var appoint_button = "<span><span class='btn'>"+identity_name+"</span><i class='fa fa-remove' onclick='remove_appoint(this,"+type+","+identity_id+")'></i></span>";
            show_appoint.append(appoint_button);
        }
        //归位
        $(that).val(0);
    }
    //移除商品类别
    function remove_appoint(that,type,gid){
        var appoint_remove = '';
        if(type == 1){
            appoint_remove = $('#hide_appoint');
        }else{
            appoint_remove = $('#hide_appoint2');
        }
        //移除当前button
        $(that).parent().remove();
        //删去隐藏提交数据中的id
        var appoint_arr = appoint_remove.val().split(',');
        appoint_arr.splice($.inArray(gid,appoint_arr),1);
        var temp = appoint_arr.join(",");
        appoint_remove.val(temp);
    }
</script>
</body>
</html>