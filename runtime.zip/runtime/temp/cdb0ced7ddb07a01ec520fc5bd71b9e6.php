<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:37:"./template/mobile/new/cart\cart4.html";i:1551506935;s:40:"./template/mobile/new/common\header.html";i:1551506935;s:44:"./template/mobile/new/common\header_nav.html";i:1551506935;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=0">
    <link rel="stylesheet" type="text/css" href="__STATIC__/assets/weui/weui.css">
    <link rel="stylesheet" type="text/css" href="__STATIC__/assets/css/comm.css">
    <link rel="stylesheet" type="text/css" href="__STATIC__/assets/css/index.css">
    <link rel="stylesheet" type="text/css" href="__STATIC__/assets/js/lib/Swiper-3.4.2/swiper.min.css">
    <link rel="stylesheet" type="text/css" href="__STATIC__/assets/css/category.css">
    <script src="__STATIC__/assets/js/lib/jquery.min.2.1.3.js"></script>
    <script src="__STATIC__/assets/js/lib/weui.min.js"></script>
    <script src="__STATIC__/assets/js/comm.js"></script>
    <link rel="stylesheet" type="text/css" href="__STATIC__/assets/css/style.css">
    <script src="__PUBLIC__/js/global.js"></script>
    <script src="__STATIC__/js/layer.js"  type="text/javascript" ></script>
    <script src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>

    <script src="__STATIC__/assets/js/wxsdkcommon.js?v=1455"></script>

    <title><?php if($title): ?>订单提交--<?php endif; ?><?php echo $tpshop_config['shop_info_store_title']; ?></title>
</head>
<script>
    var appId = "<?php echo $signPackage['appId']; ?>";
    var timestamp = "<?php echo $signPackage['timestamp']; ?>";
    var nonceStr = "<?php echo $signPackage['nonceStr']; ?>";
    var signature = "<?php echo $signPackage['signature']; ?>";
</script>
<body class="g4" <?php if(CONTROLLER_NAME == 'Index' and ACTION_NAME  == 'index'): ?> onload="countTime()" <?php endif; ?> >


<style>
    .cardbox{
        position: relative;
        margin-top: 15px;
        margin-left: 10px;
        margin-right:10px;
        margin-bottom: 15px;
        border-top-left-radius: 5px;
        border-top-right-radius: 5px;
        box-shadow: 0 0 10px rgba(0,0,0,0.05);
        overflow: visible;
    }
    .cardbox:before{
        content: "";
        position: absolute;
        width: 1.35rem;
        height: 1.15rem;
        background: url(../assets/images/kouzi.png) no-repeat;
        background-size: 100%;
        right: 1rem;
        top: -0.37rem;
    }
    .cardbox:after{
        content: "";
        position: absolute;
        left: 0;
        right: 0;
        bottom: -10px;
        height: 10px;
        background: url(../assets/images/cardbottom.png) no-repeat;
        background-size: 100%;
    }
    .card-top:after,.card-top:before{
        position: absolute;
        width: 16px;
        height: 16px;
        border-radius: 50%;
        background-color: #f8f8f8;
        content: "";
        z-index:9;
        bottom: -8px;
    }
    .card-top:after{
        right: -8px;
    }
    .card-top:before{
        left: -8px;
    }
    .weui-cells_checkbox .weui-icon-checked:before{
        border:0px;
    }
</style>


<div class="page">
    <div class="page-hd">
        <div class="header">
            <div class="header-left">
                <a href=javascript:history.back(-1) class="left-arrow"></a>
            </div>
            <div class="header-title">订单提交</div>
            <div class="header-right"><a href="#"></a> </div>
        </div>
    </div>


    <div class="page-bd">
        <div class="weui-cells weui-cells_checkbox cardbox">
            <div class="weui-cell" style="padding: 1rem 0; border-bottom: 1px dashed #e0e0e0;">

                <div class="weui-cell__bd tc card-top">
                    <?php if($list): ?>
                    <div>付款收益积分</div>
                    <div class="text-red mt5"><span class="fs12">￥</span><b class="fs20"><?php echo $order[trade_price]; ?></b></div>
                    <div>付款配额</div>
                    <div class="text-red mt5"><span class="fs12">￥</span><b class="fs20"><?php echo $order[quota]; ?></b></div>
                <?php endif; if($order['type'] == 2): ?>
                        <div>付款收益积分</div>
                        <div class="text-red mt5"><span class="fs12">￥</span><b class="fs20"><?php echo $order[order_amount]; ?></b></div>
                        <?php if($order['prom_type'] == 0): ?>
                        <div>付款消费积分</div>
                        <div class="text-red mt5"><span class="fs12">￥</span><b class="fs20"><?php echo $order[shop_integral]; ?></b></div>
                        <?php endif; endif; if($order['type'] == 1): ?>
                        <div>付款收益积分</div>
                        <div class="text-red mt5"><span class="fs12">￥</span><b class="fs20"><?php echo $order[order_amount]; ?></b></div>
                    <?php endif; ?>

                </div>

            </div>
           <!-- <label class="weui-cell tbornone after-left__0 weui-check__label" for="s11">
                <div class="weui-cell__hd">
                    <input type="checkbox" class="weui-check" name="checkbox1" id="s11" checked="checked">
                    <i class="weui-icon-checked"></i>
                </div>
                <div class="weui-cell__bd">
                    <div class="fs11">可用余额支付</div>
                    <div class="fs9 text-muted">当前可用余额￥365</div>
                </div>
                <div><span>￥</span><b>365.00</b></div>
            </label>
            <label class="weui-cell after-left__0 weui-check__label" for="s12">
                <div class="weui-cell__hd">
                    <input type="checkbox" class="weui-check" name="checkbox1" id="s12" checked="checked">
                    <i class="weui-icon-checked"></i>
                </div>
                <div class="weui-cell__bd">
                    <div class="fs11">可用佣金支付</div>
                    <div class="fs9 text-muted">当前可用佣金￥125</div>
                </div>
                <div><span>￥</span><b>56.00</b></div>
            </label>
            <label class="weui-cell after-left__0 weui-check__label" for="s13">
                <div class="weui-cell__hd">
                    <input type="checkbox" class="weui-check" name="checkbox1" id="s13" checked="checked">
                    <i class="weui-icon-checked"></i>
                </div>
                <div class="weui-cell__bd">
                    <div class="fs11">可用积分抵扣</div>
                    <div class="fs9 text-muted">可用积分抵扣</div>
                </div>
                <div><span>￥</span><b>32.56</b></div>
            </label>
        </div>-->
            <form action="<?php echo U('Mobile/Payment/getCode'); ?>" method="post" name="cart4_form" id="cart4_form">

            <div class="weui-panel weui-panel_access">
           <!-- <div class="weui-panel__hd">
                <div class="text-red fr" style="line-height: 1.4em;"><span class="fs12">￥</span><b
                        class="fs15">832.56</b></div>
                <div class="fs11">还需支付</div>
            </div>-->

            <div class="weui-panel__bd fs10">
                <div class="weui-cells mt0 weui-cells_radio">
                    <!--<?php if(is_array($paymentList) || $paymentList instanceof \think\Collection || $paymentList instanceof \think\Paginator): if( count($paymentList)==0 ) : echo "" ;else: foreach($paymentList as $k=>$v): ?>-->
                        <!--<label class="weui-cell weui-cell_access weui-check__label" for="x<?php echo $k; ?>">-->
                            <!--<div class="weui-cell__hd">-->
                                <!--<input type="radio"  class="weui-check" value="pay_code=<?php echo $v['code']; ?>" name="pay_radio" id="x<?php echo $k; ?>">-->
                                <!--<span class="weui-icon-checked"></span></div>-->
                            <!--<div class="weui-cell__bd">-->
                                <!--<div class="fs11"> <?php echo $v[name]; ?></div>-->
                            <!--</div>-->
                            <!--<div class="weui-cell__ft">-->
                                <!--<img style="width: 0.8rem;" src="/plugins/<?php echo $v['type']; ?>/<?php echo $v['code']; ?>/<?php echo $v['icon']; ?>" alt="">-->
                            <!--</div>-->
                        <!--</label>-->
                      <!--  <li  onClick="changepay(this);">
                            <label>
                                <div class="radio fl">
							<span class="che <?php echo $k; ?>">
								<i>
                                    <input type="radio"   value="pay_code=<?php echo $v['code']; ?>" class="c_checkbox_t" name="pay_radio" style="display:none;"/>
                                </i>
							</span>
                                </div>
                                <div class="pay-list-img fl">
                                    <img src="/plugins/<?php echo $v['type']; ?>/<?php echo $v['code']; ?>/<?php echo $v['icon']; ?>"/>
                                </div>
                                <div class="pay-list-font fl">
                                    <?php echo $v[name]; ?>
                                </div>
                            </label>
                        </li>-->
                    <!--<?php endforeach; endif; else: echo "" ;endif; ?>-->
                  <!--  <label class="weui-cell weui-cell_access weui-check__label" for="x11">
                        <div class="weui-cell__hd"><input type="radio" checked class="weui-check" name="radio1"
                                                          id="x11">
                            <span class="weui-icon-checked"></span></div>
                        <div class="weui-cell__bd">
                            <div class="fs11">在线支付</div>
                        </div>
                        <div class="weui-cell__ft">
                            <img style="width: 0.8rem;" src="../assets/images/pay_icon01.png" alt=""> <span>微信支付</span>
                        </div>
                    </label>
                    <label class="weui-cell weui-check__label" for="x12">
                        <div class="weui-cell__hd"><input type="radio" class="weui-check" name="radio1" id="x12">
                            <span class="weui-icon-checked"></span></div>
                        <div class="weui-cell__bd">
                            <div class="fs11">货到付款</div>
                        </div>
                    </label>-->
                    <input type="hidden" id="order_id" name="order_id" value="<?php echo $order['order_id']; ?>" />
                    <input type="hidden" id="setmeal" name="setmeal" value="<?php echo $setmeal; ?>" />
                    <input type="hidden" id="num" name="num" value="<?php echo $num; ?>" />

                </div>
            </div>
        </div>
    </form>
            <div class="weui-btn-area">
            <a href="javascript:void(0);" onClick="pay()" class="weui-btn weui-btn_primary">去付款</a>
        </div>
    </div>

</div>
<script src="__STATIC__/assets/dist/assets/js/jquery-weui.min.js"></script>
<script>
    function pay(){
        $.prompt({
            title: '安全密码',
            text: '请输入安全密码',
            input: '',
            empty: false, // 是否允许为空
            onOK: function (input) {
                //点击确认
                $.ajax({
                    type : "POST",
                    url:"<?php echo U('Mobile/Payment/getCode'); ?>",//+tab,
                    dataType:'JSON',
                    data :{'id':$("#order_id").val(),'num':$("#num").val(),'setmeal':$("#setmeal").val(),'paypwd':input},
                    success: function(data)
                    {
                        if(data.code == 1){
                            // console.log(data.url);return false;
                            layer.open({content:data.msg,time:2,end:function(){
                                    window.location.href='/Mobile/Order/order_list';
                                }});
                        }else{
                            layer.open({content:data.msg,time:2});
                        }
                    },
                    error:function(){
                        layer.open({content:'请稍后再试',time:2});
                    }
                });
            },
            onCancel: function () {
                $(".weui-dialog").remove();
                $(".weui-mask").remove();
                //点击取消
            }
        });
        $("#weui-prompt-input").attr('type','password');
        $("#weui-prompt-input").focus();
        return false;
        console.log($("#order_id").val());
        console.log($("#num").val());
        console.log($("#setmeal").val());


        // $('#cart4_form').submit();
        // return;
        //微信JS支付
    }

</script>

