<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:37:"./template/mobile/new/user\email.html";i:1551506979;s:40:"./template/mobile/new/public\header.html";i:1551506937;s:44:"./template/mobile/new/public\header_nav.html";i:1551506937;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>银行卡信息--<?php echo $tpshop_config['shop_info_store_title']; ?></title>
    <link rel="stylesheet" href="__STATIC__/css/style.css">
    <link rel="stylesheet" type="text/css" href="__STATIC__/css/iconfont.css"/>
    <script src="__STATIC__/js/jquery-3.1.1.min.js" type="text/javascript" charset="utf-8"></script>
    <!--<script src="__STATIC__/js/zepto-1.2.0-min.js" type="text/javascript" charset="utf-8"></script>-->
    <script src="__STATIC__/js/style.js" type="text/javascript" charset="utf-8"></script>
    <script src="__STATIC__/js/mobile-util.js" type="text/javascript" charset="utf-8"></script>
    <script src="__PUBLIC__/js/global.js"></script>
    <script src="__STATIC__/js/layer.js"  type="text/javascript" ></script>
    <script src="__STATIC__/js/swipeSlide.min.js" type="text/javascript" charset="utf-8"></script>
    <script src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>

    <script src="__STATIC__/assets/js/wxsdkcommon.js?v=1455"></script>
</head>
<script>
    var appId = "<?php echo $signPackage['appId']; ?>";
    var timestamp = "<?php echo $signPackage['timestamp']; ?>";
    var nonceStr = "<?php echo $signPackage['nonceStr']; ?>";
    var signature = "<?php echo $signPackage['signature']; ?>";
</script>
<body class="">

<div class="classreturn loginsignup ">
    <div class="content">
        <div class="ds-in-bl return">
            <a href="<?php echo U('Mobile/User/userinfo'); ?>"><img src="__STATIC__/images/return.png" alt="返回"></a>
        </div>
        <div class="ds-in-bl search center">
            <span>银行卡信息</span>
        </div>
        <div class="ds-in-bl menu">
          <!--  <a href="javascript:void(0);"><img src="__STATIC__/images/class1.png" alt="菜单"></a>-->
        </div>
    </div>
</div>
<div class="flool tpnavf">
    <div class="footer">
        <ul>
            <li>
                <a class="yello" href="<?php echo U('Index/index'); ?>">
                    <div class="icon">
                        <i class="icon-shouye iconfont"></i>
                        <p>首页</p>
                    </div>
                </a>
            </li>
            <li>
                <a href="<?php echo U('Goods/categoryList'); ?>">
                    <div class="icon">
                        <i class="icon-fenlei iconfont"></i>
                        <p>分类</p>
                    </div>
                </a>
            </li>
            <li>
                <!--<a href="shopcar.html">-->
                <a href="<?php echo U('Cart/index'); ?>">
                    <div class="icon">
                        <i class="icon-gouwuche iconfont"></i>
                        <p>购物车</p>
                    </div>
                </a>
            </li>
            <li>
                <a href="<?php echo U('User/index'); ?>">
                    <div class="icon">
                        <i class="icon-wode iconfont"></i>
                        <p>我的</p>
                    </div>
                </a>
            </li>
        </ul>
    </div>
</div>
<style>
    .fetchcode{
        background-color: #ec5151;
        border-radius: 0.128rem;
        color: white;
        padding: 0.55467rem 0.21333rem;
        vertical-align: middle;
        font-size: 0.59733rem;
    }
    #fetchcode{
        background:#898995;
        border-radius: 0.128rem;
        color: white;
        padding: 0.55467rem 0.21333rem;
        vertical-align: middle;
        font-size: 0.59733rem;
    }
</style>
		<div class="loginsingup-input">
			<form action="<?php echo U('Mobile/User/userinfo'); ?>" method="post" onsubmit="return submitverify(this)">
				<input name="wx_codes" value="1" hidden>
				<div class="reset-pwd-title">银行卡信息</div>
				<div class="lsu bk">
					<span style="float: left">开户银行：</span>
					<input type="text" name="bank" id="bank" value="<?php echo $wx_code['bank']; ?>" placeholder="请输入开户银行"/>
				</div>
				<div class="lsu bk">
					<span style="float: left">开户账号：</span>
					<input type="text" name="bank_num" id="bank_num" value="<?php echo $wx_code['bank_num']; ?>" placeholder="请输入开户账号"/>
				</div>
				<div class="lsu bk">
					<span style="float: left">开户姓名：</span>
					<input type="text" name="bank_name" id="bank_name" value="<?php echo $wx_code['bank_name']; ?>" placeholder="请输入开户姓名"/>
				</div>
				<div class="lsu bk">
					<span style="float: left">身份证号：</span>
					<input type="text" name="num" id="num" value="<?php echo $wx_code['num']; ?>" placeholder="请输入身份证号"/>
				</div>
				<div class="lsu-submit">
                    <input type="submit" value="确认修改" />
				</div>
			</form>
		</div>
<script type="text/javascript">
    //验证邮箱
    function useremail(email){
        if(email == ''){
            layer.open({content:'请输入您的邮箱！',time:3});
            return false;
        }else if(checkEmail(email)){
            $.ajax({
                type : "GET",
                url:"/index.php?m=Home&c=Api&a=issetMobileOrEmail",//+tab,
//			url:"<?php echo U('Mobile/User/comment',array('status'=>$_GET['status']),''); ?>/is_ajax/1/p/"+page,//+tab,
                data :{mobile:email},// 你的formid 搜索表单 序列化提交
                success: function(data)
                {
                    if(data == '0')
                    {
                        return true;
                    }else{
                        layer.open({content:'邮箱已存在！',time:3});
                        return false;
                    }
                }
            });
        }else{
            layer.open({content:'邮箱地址不正确！',time:3});
            return false;
        }
    }

    //提交前验证表单
    function submitverify(obj){
        var bank = $.trim($('#bank').val());
        var bank_num = $.trim($('#bank_num').val());
        var bank_name = $.trim($('#bank_name').val());
        var num = $.trim($('#num').val());
        if(bank == ''||bank_num == ''||bank_name == ''||num == ''){
            layer.open({content:'所有信息必填！',time:3});
            return false;
        }
//                var emailcode = $('#mobile_code').val();
//                if(emailcode == ''){
//                    layer.open({content:'验证码不能空！',time:3});
//                    return false;
//                }
        $(obj).onsubmit();
    }
</script>
</body>
</html>
