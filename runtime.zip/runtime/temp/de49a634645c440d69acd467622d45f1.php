<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:51:"./application/admin/view2/user\_user\ajaxindex.html";i:1551506740;}*/ ?>
<div id="flexigrid" cellpadding="0" cellspacing="0" border="0">
    <table>
        <tbody>
        <?php if(is_array($userList) || $userList instanceof \think\Collection || $userList instanceof \think\Paginator): $i = 0; $__LIST__ = $userList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?>
            <tr data-id="<?php echo $list['user_id']; ?>">
                <td class="sign">
                    <div style="width: 24px;"><i class="ico-check"></i></div>
                </td>
                <td align="left" class="">
                    <div style="text-align: center; width: 50px;"><?php echo $list['user_id']; ?></div>
                </td>
                <td align="left" class="">
                    <div style="text-align: center; width: 150px;"><?php echo $list['mobile']; ?></div>
                </td>
                <td align="left" class="">
                    <div style="text-align: center; width: 150px;"><?php echo $list['nickname']; ?></div>
                </td>
                <td align="left" class="">
                    <div style="text-align: center; width: 80px;"><?php if(empty($list[level]) || (($list[level] instanceof \think\Collection || $list[level] instanceof \think\Paginator ) && $list[level]->isEmpty())): ?>注册会员<?php else: ?><?php echo $level[$list[level]]; endif; ?></div>
                </td>
                <td align="left" class="">
                    <div style="text-align: center; width: 100px;"><?php echo $list['user_money']; ?></div>
                </td>
                <td align="left" class="">
                    <div style="text-align: center; width: 100px;"><?php echo $list['frozen_money']; ?>
                    </div>
                </td>
                <td align="left" class="">
                    <div style="text-align: center; width: 100px;"><?php echo $list['distribut_money']; ?></div>
                </td>
                <td align="left" class="">
                    <div style="text-align: center; width: 100px;"><?php echo $list['last_monthly_performance']; ?>
                    </div>
                </td>
                <td align="left" class="">
                    <div style="text-align: center; width: 100px;"><?php echo $list['monthly_performance']; ?></div>
                </td>
                <!--<td align="left" class="">-->
                    <!--<div style="text-align: center; width: 100px;"><?php echo $list['rebate_revenue']; ?>-->
                    <!--</div>-->
                <!--</td>-->
                <td align="left" class="">
                    <div style="text-align: center; width: 50px;"><?php echo $list['first_leader']; ?></div>
                </td>
                <td align="left" class="">
                    <div style="text-align: center; width: 150px;"><?php echo date('Y-m-d H:i:s',$list['reg_time']); ?></div>
                </td>
                <td align="left" class="">
                    <div style="text-align: center; width: 50px;">
                        <?php if($list['engineer_status'] == 1): ?>
                    启用
                    <?php else: ?>
                    禁用
                        <?php endif; ?>
                    </div>
                </td>
                <td align="center" class="handle">
                    <div style="text-align: center; width: 250px;">
                        <a class="btn blue" href="<?php echo U('Admin/User.User/detail',array('id'=>$list['user_id'],'inc_type'=> 1)); ?>"><i class="fa fa-pencil-square-o"></i>详情</a>
                        <a class="btn blue" href="<?php echo U('Admin/User.User/index',array('first_leader'=>$list['user_id'])); ?>"><i class="fa fa-pencil-square-o"></i>查看下级</a>
                        <a class="btn blue" href="<?php echo U('Admin/User.User/account_log',array('id'=>$list['user_id'])); ?>"><i class="fa fa-search"></i>资金调节</a>
                        <a class="btn blue" href="<?php echo U('Admin/User.User/level_update',array('user_id'=>$list['user_id'])); ?>"><i class="fa fa-search"></i>等级变更</a>
                        <a class="btn blue" href="<?php echo U('Admin/User.User/shop_index',array('user_id'=>$list['user_id'],'user'=>$list['mobile'])); ?>"><i class="fa fa-steam"></i>购买明细</a>
                        <!-- <a class="btn blue" href="<?php echo U('Admin/User.User/address',array('id'=>$list['user_id'])); ?>"><i class="fa fa-steam"></i>收货地址</a> -->
                        <!-- <a class="btn red"  href="javascript:void(0)" data-id="<?php echo $list['user_id']; ?>"  data-url="<?php echo U('Admin/User.User/ajax_delete'); ?>" onClick="delfun(this)"><i class="fa fa-trash-o"></i>删除</a> -->
                        <?php if($list['engineer_status'] == 0): ?>
                        <a class="btn blue"  href="javascript:void(0)" data-id="<?php echo $list['user_id']; ?>"  data-url="<?php echo U('Admin/User.User/ajax_edit'); ?>" onClick="ajax_edit(1,this)"><i class="fa fa-pencil-square-o"></i>启用</a><?php endif; if($list['engineer_status'] == 1): ?>
                        <a class="btn blue"  href="javascript:void(0)" data-id="<?php echo $list['user_id']; ?>"  data-url="<?php echo U('Admin/User.User/ajax_edit'); ?>" onClick="ajax_edit(0,this)"><i class="fa fa-pencil-square-o"></i>禁用</a>
                    <?php endif; ?>
                    </div>
                </td>
                <td align="" class="" style="width: 100%;">
                    <div>&nbsp;</div>
                </td>
            </tr>
        <?php endforeach; endif; else: echo "" ;endif; ?>
        </tbody>
    </table>
</div>
<!--分页位置-->
<?php echo $page; ?>
<script>
    $(".pagination  a").click(function(){
        var page = $(this).data('p');
        ajax_get_table('search-form2',page);
    });
    $(document).ready(function(){
        // 表格行点击选中切换
        $('#flexigrid >table>tbody>tr').click(function(){
            $(this).toggleClass('trSelected');
        });
        $('#user_count').empty().html("<?php echo $pager->totalRows; ?>");
    });
    function delfun(obj) {
        // 删除按钮
        layer.confirm('确认删除？', {
            btn: ['确定', '取消'] //按钮
        }, function () {
            $.ajax({
                type: 'post',
                url: $(obj).attr('data-url'),
                data: {id : $(obj).attr('data-id')},
                dataType: 'json',
                success: function (data) {
                    layer.closeAll();
                    if (data.status == 1) {
                        $(obj).parent().parent().parent().remove();
                    } else {
                        layer.alert(data.msg, {icon: 2});
                    }
                }
            })
        }, function () {
        });
    }
    function ajax_edit(type,obj) {

        // 删除按钮
        layer.confirm('确认？', {
            btn: ['确定', '取消'] //按钮
        }, function () {
            $.ajax({
                type: 'post',
                url: "<?php echo U('Admin/User.User/ajax_edit'); ?>",
                data: {id : $(obj).attr('data-id'),type:type},
                dataType: 'json',
                success: function (data) {
                    //layer.closeAll();
                    if (data.status == 1) {
                        layer.alert(data.msg, {icon: 1});
                        location.reload();
                    } else {
                        layer.alert(data.msg, {icon: 2});                       
                    }                    
                }
            })
        }, function () {
        });
    }
</script>