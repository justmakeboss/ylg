<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:39:"./template/mobile/new/index\retail.html";i:1551535596;}*/ ?>
<!DOCTYPE html>
<html lang="zh-cmn-Hans">
<head>
    <meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=0,viewport-fit=cover">
<link rel="stylesheet" href="__STATIC__/assets/assets/css/zpui.css"/>
<link rel="stylesheet" href="__STATIC__/assets/assets/css/all.css"/>
<script src="__STATIC__/assets/assets/js/page.js"></script>

    <title>活动区</title>
</head>
<body>
<div class="page">
    <div class="page-hd">
        <div class="header bor-1px-b">
    <div class="header-left">
        <a href="javascript:history.go(-1)" class="left-arrow"></a>
    </div>
    <div class="header-title">活动区</div>
    <div class="header-right">
        <a href="#"></a>
    </div>
</div>
    </div>

    <div class="page-bd">
        <!-- 页面内容-->
        <div class="back-no">
            <div>  
                
                 
                 
                
            </div>  

                <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
                  <input type="hidden" id="agentend_time" value="<?php echo $v['agentend_time']; ?>">
                <div class="weui-cell__by <?php if($v[stocks] == 0): ?>active<?php endif; ?>" >
                <a href="<?php echo U('Mobile/goods/goodsInfo',array('id'=>$v['goods_id'])); ?>">
                   <div class="img-100"><img src="<?php echo (isset($v['original_img']) && ($v['original_img'] !== '')?$v['original_img']:'__STATIC__/assets/assets/images/01_03.png'); ?>"></div>
                   <!--<div class="bet-time fs-22 color-f9">-->
                        <!--<div class="time-ol">-->
                          <!--<span class="opwe _d">00</span><span class="_h">00</span> <span class="_m">00</span><span class="_s">00</span>-->
                        <!--</div>-->
                   <!--</div>-->
                   <div class="fs-26 color-32 font-w600 onetn"><?php echo $v[goods_name]; ?></div>
                    <div class="fs-26 font-w500 color-f0 pg-t10"><span class="fs-18">￥</span><?php echo $v['shop_price']; ?></div>
                   </a>

               </div>
                <?php endforeach; endif; else: echo "" ;endif; ?>
                <!-- <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0;$__LIST__ = is_array($list) ? array_slice($list,2,2, true) : $list->slice(2,2, true); if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
                  <input type="hidden" id="agentend_time2" value="<?php echo $v['agentend_time']; ?>">
                <div class="weui-cell__by <?php if($v[stocks] == 0): ?>active<?php endif; ?>" >
                <a href="<?php echo U('Mobile/goods/goodsInfo',array('id'=>$v['goods_id'])); ?>">
                   <div class="img-100"><img src="<?php echo (isset($v['original_img']) && ($v['original_img'] !== '')?$v['original_img']:'__STATIC__/assets/assets/images/01_03.png'); ?>"></div>
                   <div class="bet-time fs-22 color-f9">
                        <div class="time-ol">
                          <span class="opwe _d2">00</span><span class="_h2">00</span> <span class="_m2">00</span><span class="_s2">00</span>
                        </div>
                   </div>
                   <div class="fs-26 color-32 font-w600 onetn"><?php echo $v[goods_name]; ?></div>
                   <div class="fs-26 font-w500 color-f0 pg-t10"><span class="fs-18">￥</span><?php echo $v['shop_price']; ?></div>
                   </a>
                
                               </div>
                <?php endforeach; endif; else: echo "" ;endif; ?> -->

               <!-- <div class="weui-cell__by">
               <a href="<?php echo U('Mobile/goods/goodsInfo',array('id'=>$v['goods_id'])); ?>">
                   <div class="sker">已售罄</div>
                   <div class="img-100"><img src="__STATIC__/assets/assets/images/01_03.png"></div>
                   <div class="bet-time fs-22 color-f9">
                        <div class="time-ol"><span class="opwe" id="_d">00</span><span id="_h">00</span> <span id="_m">00</span><span id="_s">00</span></div>
                   </div>
                   <div class="fs-26 color-32 font-w600 onetn">美素佳儿荷兰配方奶粉4段美素佳儿荷兰配方奶粉4段</div>
                   <div class="fs-26 font-w500 color-f0 pg-t10"><span class="fs-18">￥</span>289.00~399.00</div>
                    </a>
               </div>
               <div class="weui-cell__by active">
                    <div class="sker">已售罄</div>
                   <div class="img-100"><img src="__STATIC__/assets/assets/images/01_06.png"></div>
                   <div class="bet-time fs-22 color-f9">
                        <div class="time-ol"><span class="opwe" id="_d">00</span><span id="_h">00:</span> <span id="_m">00:</span><span id="_s">00</span></div>
                   </div>
                   <div class="fs-26 color-32 font-w600 onetn">美素佳儿荷兰配方奶粉4段美素佳儿荷兰配方奶粉4段</div>
                   <div class="fs-26 font-w500 color-f0 pg-t10"><span class="fs-18">￥</span>289.00~399.00</div>
               </div>
               <div class="weui-cell__by  active">
                   <div class="sker">已售罄</div>
                   <div class="img-100"><img src="__STATIC__/assets/assets/images/01_10.jpg"></div>
                   <div class="bet-time fs-22 color-f9">
                       <div class="time-ol"><span class="opwe" id="_d">00</span><span id="_h">00:</span> <span id="_m">00:</span><span id="_s">00</span></div>
                   </div>
                   <div class="fs-26 color-32 font-w600 onetn">美素佳儿荷兰配方奶粉4段美素佳儿荷兰配方奶粉4段</div>
                   <div class="fs-26 font-w500 color-f0 pg-t10"><span class="fs-18">￥</span>289.00~399.00</div>
               </div>
               <div class="weui-cell__by  active">
                   <div class="sker">已售罄</div>
                   <div class="img-100"><img src="__STATIC__/assets/assets/images/01_12.png"></div>
                   <div class="bet-time fs-22 color-f9">
                        <div class="time-ol"><span class="opwe" id="_d">00</span><span id="_h">00:</span> <span id="_m">00:</span><span id="_s">00</span></div>
                   </div>
                   <div class="fs-26 color-32 font-w600 onetn">美素佳儿荷兰配方奶粉4段美素佳儿荷兰配方奶粉4段</div>
                   <div class="fs-26 font-w500 color-f0 pg-t10"><span class="fs-18">￥</span>289.00~399.00</div>
               </div>

        </div>

    </div>
    <div class="bottom-tabbar-wrapper">
  <div class="bottom-tabbar">
    <a href="index.html" class="bottom-tabbar__item active">
        <span class="icon">
            <img src="__STATIC__/assets/assets/images/bottom_icon01.png"/>
            <img class="lhimg" src="__STATIC__/assets/assets/images/bottom_icon01_lh.png"/>
        </span>
      <p class="label">首页</p>
    </a>
    <a href="消息.html" class="bottom-tabbar__item ">
        <span class="icon">
            <img src="__STATIC__/assets/assets/images/bottom_icon02.png"/>
            <img class="lhimg" src="__STATIC__/assets/assets/images/bottom_icon02_lh.png"/>
        </span>
      <p class="label">消息</p>
    </a>
    <a href="云仓.html" class="bottom-tabbar__item ">
        <span class="icon">
            <img src="__STATIC__/assets/assets/images/bottom_icon03.png"/>
            <img class="lhimg" src="__STATIC__/assets/assets/images/bottom_icon03_lh.png"/>
        </span>
      <p class="label">云仓</p>
    </a>
    <a href="直购.html" class="bottom-tabbar__item ">
        <span class="icon">
            <img src="__STATIC__/assets/assets/images/bottom_icon04.png"/>
            <img class="lhimg" src="__STATIC__/assets/assets/images/bottom_icon04_lh.png"/>
        </span>
      <p class="label">直购</p>
    </a>
    <a href="登录.html" class="bottom-tabbar__item ">
        <span class="icon">
            <img src="__STATIC__/assets/assets/images/bottom_icon05.png"/>
            <img class="lhimg" src="__STATIC__/assets/assets/images/bottom_icon05_lh.png"/>
        </span>
      <p class="label">我的</p>
    </a>
  </div> -->
        <div class="bottom-tabbar">
            <a  <?php if(CONTROLLER_NAME == 'Index'): ?>class="bottom-tabbar__item @@item1 active " <?php else: ?>class="bottom-tabbar__item @@item1" <?php endif; ?> href="<?php echo U('Index/index'); ?>" >
            <span class="icon">
                        <img src="__STATIC__/assets/images/tabbar_icon01_lh.jpg"/>
            <img class="lhimg" src="__STATIC__/assets/images/tabbar_icon01.jpg"/>
        </span>
            <p class="label">首页</p>
            </a>
            <a href="<?php echo U('Goods/categoryList'); ?>" <?php if(CONTROLLER_NAME == 'Goods'): ?>class="bottom-tabbar__item @@item3 active"<?php else: ?>class="bottom-tabbar__item @@item3"<?php endif; ?> >
            <span class="icon">
            <img src="__STATIC__/assets/images/tabbar_icon03_lh.jpg"/>
            <img class="lhimg" src="__STATIC__/assets/images/bottom_icon03.jpg"/>
        </span>
            <p class="label">分类</p>
            </a>
            <a href="<?php echo U('Cart/index'); ?>"  <?php if(CONTROLLER_NAME == 'Cart'): ?>class="bottom-tabbar__item @@item2 active " <?php else: ?>class="bottom-tabbar__item @@item2"<?php endif; ?>>
            <span class="icon">
            <img src="__STATIC__/assets/images/tabbar_icon02_lh.jpg"/>
            <img class="lhimg" src="__STATIC__/assets/images/tabbar_icon02.jpg"/>
        </span>
            <p class="label">购物车</p>
            </a>

            <a href="<?php echo U('User/index'); ?>" <?php if(CONTROLLER_NAME == 'User'): ?>class="bottom-tabbar__item @@item4 active"<?php else: ?>class="bottom-tabbar__item @@item4"<?php endif; ?> >
            <span class="icon">
            <img src="__STATIC__/assets/images/tabbar_icon04_lh.jpg"/>
            <img class="lhimg" src="__STATIC__/assets/images/tabbar_icon04.jpg"/>
        </span>
            <p class="label">我的</p>
            </a>
        </div>
</div>
</div>
<script src="__STATIC__/assets/assets/js/lib/jquery-2.1.4.js"></script>
<script src="__STATIC__/assets/assets/js/jquery-weui.min.js"></script>
<script src="__STATIC__/assets/assets/js/lib/fastclick.js"></script>
<script>
  $(function() {
    FastClick.attach(document.body);
  });
</script>

<script type="text/javascript">  
    // function countTime() {
    //     //获取当前时间
    //     var date = new Date();
    //     var now = date.getTime();
    //     //设置截止时间
    //     var str=$('#agentend_time').val();//"2018/12/14 12:00:00";
    //     //console.log(str);
    //     var endDate = new Date(str);
    //     var end = endDate.getTime();
    //
    //     //时间差
    //     var leftTime = end-now;
    //     //定义变量 d,h,m,s保存倒计时的时间
    //     var d,h,m,s;
    //     if (leftTime>=0) {
    //         d = Math.floor(leftTime/1000/60/60/24);
    //         h = Math.floor(leftTime/1000/60/60%24);
    //         m = Math.floor(leftTime/1000/60%60);
    //         s = Math.floor(leftTime/1000%60);
    //     }
    //     //将0-9的数字前面加上0，例1变为01
    //     d = checkTime(d);
    //     h = checkTime(h);
    //     m = checkTime(m);
    //     s = checkTime(s);
    //     function checkTime(i){
    //         if (i<10) {
    //             i = "0"+i;
    //         }
    //         return i;
    //     }
    //     //将倒计时赋值到div中
    //     $("._d").text(d+"天");
    //     $("._h").text(h+":");
    //     $("._m").text(m+":");
    //     $("._s").text(s+"");
    //     //递归每秒调用countTime方法，显示动态时间效果
    //     setTimeout(countTime,1000);
    //     countTime2();
    // }
    // function countTime2() {
    //     //获取当前时间
    //     var date = new Date();
    //     var now = date.getTime();
    //     //设置截止时间
    //     var str=$('#agentend_time2').val();//"2018/12/15 12:00:00";
    //     //console.log(str);
    //     var endDate = new Date(str);
    //     var end = endDate.getTime();
    //
    //     //时间差
    //     var leftTime = end-now;
    //     //定义变量 d,h,m,s保存倒计时的时间
    //     var d,h,m,s;
    //     if (leftTime>=0) {
    //         d = Math.floor(leftTime/1000/60/60/24);
    //         h = Math.floor(leftTime/1000/60/60%24);
    //         m = Math.floor(leftTime/1000/60%60);
    //         s = Math.floor(leftTime/1000%60);
    //     }
    //     //将0-9的数字前面加上0，例1变为01
    //     d = checkTime(d);
    //     h = checkTime(h);
    //     m = checkTime(m);
    //     s = checkTime(s);
    //     function checkTime(i){
    //         if (i<10) {
    //             i = "0"+i;
    //         }
    //         return i;
    //     }
    //     //将倒计时赋值到div中
    //     $("._d2").text(d+"天");
    //     $("._h2").text(h+":");
    //     $("._m2").text(m+":");
    //     $("._s2").text(s+"");
    //
    //     //递归每秒调用countTime方法，显示动态时间效果
    //     //setTimeout(countTime2,1000);
    //
    // }
</script> 

</body>
</html>