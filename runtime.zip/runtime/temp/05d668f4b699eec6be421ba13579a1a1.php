<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:48:"./application/admin/view2/user\_user\handle.html";i:1551587617;s:44:"./application/admin/view2/public\layout.html";i:1551506736;}*/ ?>
<!doctype html>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<!-- Apple devices fullscreen -->
<meta name="apple-mobile-web-app-capable" content="yes">
<!-- Apple devices fullscreen -->
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<link href="__PUBLIC__/static/css/main.css" rel="stylesheet" type="text/css">
<link href="__PUBLIC__/static/css/page.css" rel="stylesheet" type="text/css">
<link href="__PUBLIC__/static/font/css/font-awesome.min.css" rel="stylesheet" />
<!--[if IE 7]>
  <link rel="stylesheet" href="__PUBLIC__/static/font/css/font-awesome-ie7.min.css">
<![endif]-->
<link href="__PUBLIC__/static/js/jquery-ui/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
<link href="__PUBLIC__/static/js/perfect-scrollbar.min.css" rel="stylesheet" type="text/css"/>
<style type="text/css">html, body { overflow: visible;}</style>
<script type="text/javascript" src="__PUBLIC__/static/js/jquery.js"></script>
<script type="text/javascript" src="__PUBLIC__/static/js/jquery-ui/jquery-ui.min.js"></script>
<script type="text/javascript" src="__PUBLIC__/static/js/layer/layer.js"></script><!-- 弹窗js 参考文档 http://layer.layui.com/-->
<script type="text/javascript" src="__PUBLIC__/static/js/admin.js"></script>
<script type="text/javascript" src="__PUBLIC__/static/js/jquery.validation.min.js"></script>
<script type="text/javascript" src="__PUBLIC__/static/js/common.js"></script>
<script type="text/javascript" src="__PUBLIC__/static/js/perfect-scrollbar.min.js"></script>
<script type="text/javascript" src="__PUBLIC__/static/js/jquery.mousewheel.js"></script>
<script src="__PUBLIC__/js/myFormValidate.js"></script>
<script src="__PUBLIC__/js/myAjax2.js"></script>
<script src="__PUBLIC__/js/global.js"></script>
    <script type="text/javascript">
    function delfunc(obj){
    	layer.confirm('确认删除？', {
    		  btn: ['确定','取消'] //按钮
    		}, function(){
    		    // 确定
   				$.ajax({
   					type : 'post',
   					url : $(obj).attr('data-url'),
   					data : {act:'del',del_id:$(obj).attr('data-id')},
   					dataType : 'json',
   					success : function(data){
						layer.closeAll();
   						if(data==1){
   							layer.msg('操作成功', {icon: 1});
   							$(obj).parent().parent().parent().remove();
   						}else{
   							layer.msg(data, {icon: 2,time: 2000});
   						}
   					}
   				})
    		}, function(index){
    			layer.close(index);
    			return false;// 取消
    		}
    	);
    }

    function selectAll(name,obj){
    	$('input[name*='+name+']').prop('checked', $(obj).checked);
    }

    function get_help(obj){

		window.open("http://www.tp-shop.cn/");
		return false;

        layer.open({
            type: 2,
            title: '帮助手册',
            shadeClose: true,
            shade: 0.3,
            area: ['70%', '80%'],
            content: $(obj).attr('data-url'),
        });
    }

    function delAll(obj,name){
    	var a = [];
    	$('input[name*='+name+']').each(function(i,o){
    		if($(o).is(':checked')){
    			a.push($(o).val());
    		}
    	})
    	if(a.length == 0){
    		layer.alert('请选择删除项', {icon: 2});
    		return;
    	}
    	layer.confirm('确认删除？', {btn: ['确定','取消'] }, function(){
    			$.ajax({
    				type : 'get',
    				url : $(obj).attr('data-url'),
    				data : {act:'del',del_id:a},
    				dataType : 'json',
    				success : function(data){
						layer.closeAll();
    					if(data == 1){
    						layer.msg('操作成功', {icon: 1});
    						$('input[name*='+name+']').each(function(i,o){
    							if($(o).is(':checked')){
    								$(o).parent().parent().remove();
    							}
    						})
    					}else{
    						layer.msg(data, {icon: 2,time: 2000});
    					}
    				}
    			})
    		}, function(index){
    			layer.close(index);
    			return false;// 取消
    		}
    	);
    }

    /**
     * 全选
     * @param obj
     */
    function checkAllSign(obj){
        $(obj).toggleClass('trSelected');
        if($(obj).hasClass('trSelected')){
            $('#flexigrid > table>tbody >tr').addClass('trSelected');
        }else{
            $('#flexigrid > table>tbody >tr').removeClass('trSelected');
        }
    }
    /**
     * 批量公共操作（删，改）
     * @returns {boolean}
     */
    function publicHandleAll(type){
        var ids = '';
        $('#flexigrid .trSelected').each(function(i,o){
//            ids.push($(o).data('id'));
            ids += $(o).data('id')+',';
        });

        if(ids == ''){
            layer.msg('至少选择一项', {icon: 2, time: 2000});
            return false;
        }
        publicHandle(ids,type); //调用删除函数
    }
    /**
     * 公共操作（删，改）
     * @param type
     * @returns {boolean}
     */
    function publicHandle(ids,handle_type){
        layer.confirm('确认当前操作？', {
                    btn: ['确定', '取消'] //按钮
                }, function () {
                    // 确定
                    $.ajax({
                        url: $('#flexigrid').data('url'),
                        type:'post',
                        data:{ids:ids,type:handle_type},
                        dataType:'JSON',
                        success: function (data) {
                            layer.closeAll();
                            if (data.status == 1){
                                layer.msg(data.msg, {icon: 1, time: 2000},function(){
                                    location.href = data.url;
                                });
                            }else{
                                layer.msg(data.msg, {icon: 2, time: 2000});
                            }
                        }
                    });
                }, function (index) {
                    layer.close(index);
                }
        );
    }
</script>  

</head>
<div id="append_parent"></div>
<div id="ajaxwaitid"></div>

<div class="page">
    <div class="fixed-bar">
        <div class="item-title">
            <div class="subject">
                <h3>基础设置</h3>
                <h5>网站全局内容基本选项设置</h5>
            </div>
        </div>
    </div>
    <!-- 操作说明 -->
    <div class="explanation" id="explanation">
        <div class="title" id="checkZoom"><i class="fa fa-lightbulb-o"></i>
            <h4 title="提示相关设置操作时应注意的要点">操作提示</h4>
            <span id="explanationZoom" title="收起提示"></span></div>
        <ul>
            <li>系统基础设置。</li>
        </ul>
    </div>
    <form method="post" enctype="multipart/form-data" name="form1" action="<?php echo U('User.User/handle'); ?>">
        <input type="hidden" name="inc_type" value="<?php echo $inc_type; ?>">
        <div class="ncap-form-default">
            <dl class="row">
                <dt class="tit">
                    <label for="store_name">银行卡账户名称</label>
                </dt>
                <dd class="opt">
                    <input id="store_name" name="bank_uname" value="<?php echo $config['bank_uname']; ?>" class="input-txt" type="text" />
                    <p class="notic">银行卡账户名称</p>
                </dd>
                <dt class="tit">
                    <label for="store_name">银行卡账号</label>
                </dt>
                <dd class="opt">
                    <input id="store_name" name="bank_num" value="<?php echo $config['bank_num']; ?>" class="input-txt" type="text" />
                    <p class="notic">银行卡账号</p>
                </dd>
                <dt class="tit">
                    <label for="store_name">开户行</label>
                </dt>
                <dd class="opt">
                    <input id="store_name" name="bank_name" value="<?php echo $config['bank_name']; ?>" class="input-txt" type="text" />
                    <p class="notic">银行名称</p>
                </dd>
            </dl>
            <dl class="row">
                <dt class="tit">
                    <label for="store_logo">支付宝收款二维码</label>
                </dt>
                <dd class="opt">
                    <div class="input-file-show">
                        <span class="show">
                            <a id="alipay_a" class="nyroModal" rel="gal" href="<?php echo $config['alicode']; ?>">
                                <i id="alipay_i" class="fa fa-picture-o" onmouseover="layer.tips('<img src=<?php echo $config['alicode']; ?>>',this,{tips: [1, '#fff']});" onmouseout="layer.closeAll();"></i>
                            </a>
                        </span>
                        <span class="type-file-box">
                            <input type="text" id="alicode" name="alicode" value="<?php echo $config['alicode']; ?>" class="type-file-text">
                            <input type="button" name="button" id="button2" value="选择上传..." class="type-file-button">
                            <input class="type-file-file" onClick="GetUploadify(1,'','logo','alipay')" size="30" hidefocus="true" nc_type="change_site_logo" title="点击前方预览图可查看大图，点击按钮选择文件并提交表单后上传生效">
                        </span>
                    </div>
                    <span class="err"></span>
                    <p class="notic">支付宝收款二维码</p>
                </dd>
            </dl>
            <dl class="row">
                <dt class="tit">
                    <label for="store_logo">微信收款二维码</label>
                </dt>
                <dd class="opt">
                    <div class="input-file-show">
                        <span class="show">
                            <a id="wx_a" class="nyroModal" rel="gal" href="<?php echo $config['wxcode']; ?>">
                                <i id="wx_i" class="fa fa-picture-o" onmouseover="layer.tips('<img src=<?php echo $config['wxcode']; ?>>',this,{tips: [1, '#fff']});" onmouseout="layer.closeAll();"></i>
                            </a>
                        </span>
                        <span class="type-file-box">
                            <input type="text" id="wxcode" name="wxcode" value="<?php echo $config['wxcode']; ?>" class="type-file-text">
                            <input type="button" name="button" id="button3" value="选择上传..." class="type-file-button">
                            <input class="type-file-file" onClick="GetUploadify(1,'','logo','wx')" size="30" hidefocus="true" nc_type="change_site_logo" title="点击前方预览图可查看大图，点击按钮选择文件并提交表单后上传生效">
                        </span>
                    </div>
                    <span class="err"></span>
                    <p class="notic">微信收款二维码</p>
                </dd>
            </dl>
            <dl class="row">
                <dt class="tit">
                    <label for="reg_integral">预留资金数</label>
                </dt>
                <dd class="opt">
                    <input onKeyUp="this.value=this.value.replace(/[^\d]/g,'')" onpaste="this.value=this.value.replace(/[^\d]/g,'')" pattern="^\d{1,}$" id="goods_integral" name="reserve_funds" value="<?php echo (isset($config['reserve_funds']) && ($config['reserve_funds'] !== '')?$config['reserve_funds']:0); ?>" class="input-txt" type="text">
                    <span class="err"></span>

                    <p class="notic">单位:元</p>
                </dd>
            </dl>
            <dl class="row">
                <dt class="tit">
                    <label for="reg_integral">转让手续费</label>
                </dt>
                <dd class="opt">
                    <input id="goods_integral" name="commodity" value="<?php echo (isset($config['commodity']) && ($config['commodity'] !== '')?$config['commodity']:0); ?>" class="input-txt" type="text">
                    <span class="err"></span>

                    <p class="notic">（0.1相当于10%）</p>
                </dd>
            </dl>
            <dl class="row">
                <dt class="tit">
                    <label for="reg_integral">购买产品送配额</label>
                </dt>
                <dd class="opt">
                    <input id="invite_integral" name="invite_integral" value="<?php echo (isset($config['invite_integral']) && ($config['invite_integral'] !== '')?$config['invite_integral']:0); ?>" class="input-txt" type="text">
                    <span class="err"></span>

                    <p class="notic">活动区用收益积分购买产品送配额；（0.1相当于10%）</p>
                </dd>
            </dl>
            <dl class="row">
                <dt class="tit">
                    <label for="reg_integral">消费商返点</label>
                </dt>
                <dd class="opt">
                    累计业绩：<input onKeyUp="this.value=this.value.replace(/[^\d]/g,'')" onpaste="this.value=this.value.replace(/[^\d]/g,'')" pattern="^\d{1,}$" id="goods_integral" name="consumer" value="<?php echo (isset($config['consumer']) && ($config['consumer'] !== '')?$config['consumer']:0); ?>" class="input-txt" type="text">
                    返点：<input id="goods_integral" name="consumer2" value="<?php echo (isset($config['consumer2']) && ($config['consumer2'] !== '')?$config['consumer2']:0); ?>" class="input-txt" type="text">
                    <span class="err">只能输入整数</span>

                    <p class="notic">消费商每个直推下级累计（）业绩拿（）返点；（0.1相当于10%）</p>
                </dd>
            </dl>
            <dl class="row">
                <dt class="tit">
                    <label for="reg_integral">代理商返点</label>
                </dt>
                <dd class="opt">
                    <input id="goods_integral" name="agent_rebate" value="<?php echo (isset($config['agent_rebate']) && ($config['agent_rebate'] !== '')?$config['agent_rebate']:0); ?>" class="input-txt" type="text">
                    <span class="err"></span>

                    <p class="notic">返代理商所有下级业绩（）%补贴；（0.1相当于10%）</p>
                </dd>
            </dl>
            <dl class="row">
                <dt class="tit">
                    <label for="reg_integral">代理商合伙人返点</label>
                </dt>
                <dd class="opt">
                    直推代理商收入：<input id="goods_integral" name="agent_partner" value="<?php echo (isset($config['agent_partner']) && ($config['agent_partner'] !== '')?$config['agent_partner']:0); ?>" class="input-txt" type="text">
                    直推消费商以及所有下级的业绩：<input id="goods_integral" name="agent_partner2" value="<?php echo (isset($config['agent_partner2']) && ($config['agent_partner2'] !== '')?$config['agent_partner2']:0); ?>" class="input-txt" type="text">
                    <span class="err"></span>
                    <p class="notic">1：直推代理商收入（扣除平台20%之后）的（）%；2：直推消费商以及所有下级的业绩（）%补贴；（0.1相当于10%）</p>
                    <p class="notic">直推代理商收入只是指所有下级的返点收入，不算寄售商品的收入</p>
                </dd>
            </dl>
            <dl class="row">
                <dt class="tit">
                    <label for="reg_integral">消费积分比例</label>
                </dt>
                <dd class="opt">
                    <input id="goods_integral" name="goods_integral" value="<?php echo (isset($config['goods_integral']) && ($config['goods_integral'] !== '')?$config['goods_integral']:0); ?>" class="input-txt" type="text">
                    <span class="err"></span>

                    <p class="notic">寄售的商品，卖出后，商品所有者能得到商品价格的5%的积分，存入消费积分；（0.1相当于10%）</p>
                </dd>
            </dl>
            
            <dl class="row">
                <dt class="tit">
                    <label for="bill_charge">提现手续费</label>
                </dt>
                <dd class="opt">

                    <input name="bill_charge" id="bill_charge" value="<?php echo $config['bill_charge']; ?>" class="input-txt" type="text">
                    <span class="err"></span>

                    <p class="notic">提现手续费；（0.1相当于10%）</p>
                </dd>
            </dl>
            <dl class="row">
                <dt class="tit">
                    <label for="bill_charge">每日最多提现额度</label>
                </dt>
                <dd class="opt">

                    <input name="withdrawal_limit" id="bill_charge" value="<?php echo $config['withdrawal_limit']; ?>" class="input-txt" type="text">
                    <span class="err"></span>

                    <p class="notic">每日最多提现额度(元)</p>
                </dd>
            </dl>
            <dl class="row">
                <dt class="tit">
                    <label for="bill_charge">平台手续费</label>
                </dt>
                <dd class="opt">

                    <input name="handling_fee" id="bill_charge" value="<?php echo $config['handling_fee']; ?>" class="input-txt" type="text">
                    <span class="err"></span>

                    <p class="notic">平台手续费；（0.1相当于10%）</p>
                </dd>
            </dl>
            <dl class="row">
                <dt class="tit">
                    <label for="bill_charge">个人所得税</label>
                </dt>
                <dd class="opt">

                    <input name="personal_income" id="bill_charge" value="<?php echo $config['personal_income']; ?>" class="input-txt" type="text">
                    <span class="err"></span>

                    <p class="notic">个人所得税；（0.1相当于10%）</p>
                </dd>
            </dl>
            <dl class="row">
                    <dt class="tit">
                        <label>代理商/代理商合伙人返点2</label>
                    </dt>
                    <dd class="opt">
                        <?php if($config[pushs]): if(is_array($config[pushs]) || $config[pushs] instanceof \think\Collection || $config[pushs] instanceof \think\Paginator): if( count($config[pushs])==0 ) : echo "" ;else: foreach($config[pushs] as $k=>$v): ?>
                                <div class="add_recommend_level">
                                    <span>销售额达到&nbsp;</span>
                                        <input type="text" name="push[]" value="<?php echo $v['sales']; ?>">
                                    <span>&nbsp;,返</span>
                                    <input type="text" name="return_numbers[]" value="<?php echo $v['rebate']; ?>">
                                    <span class="zs"></span>&nbsp;&nbsp;&nbsp;
                                    <?php if($k == 0): ?>
                                        <span><a onclick="add_recommend_level(this);">添加</a>（0.1相当于10%）</span>
                                        <?php else: ?>
                                        <span><a onclick="del_recommend_level(this);">删除</a></span>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; endif; else: echo "" ;endif; else: ?>
                            <div class="add_recommend_level">
                                <span>销售额达到&nbsp;</span>
                                <input type="text" name="push[]" value="">
                                <span>&nbsp;,返</span>
                                <input type="text" name="return_numbers[]" value="">
                                <span class="zs"></span>&nbsp;&nbsp;&nbsp;
                                <span><a onclick="add_recommend_level(this);">添加</a>（0.1相当于10%）</span>
                            </div>
                        <?php endif; ?>
                    </dd>
                </dl>
            <dl class="row">
                <dt class="tit">
                    <label for="justMakeIt">活动区收货立即到账</label>
                </dt>
                <dd class="opt">

                    <input name="daozhang" id="justMakeIt" value="<?php echo $config['daozhang']; ?>" class="input-txt" type="text">
                    <span class="err"></span>

                    <p class="notic">；（0.1相当于10%）</p>
                </dd>
            </dl>
            <div class="bot"><a href="JavaScript:void(0);" class="ncap-btn-big ncap-btn-green" onclick="document.form1.submit()">确认提交</a></div>
        </div>
    </form>
</div>
<script type="text/javascript">

</script>
<div id="goTop">
    <a href="JavaScript:void(0);" id="btntop">
        <i class="fa fa-angle-up"></i>
    </a>
    <a href="JavaScript:void(0);" id="btnbottom">
        <i class="fa fa-angle-down"></i>
    </a>
</div>
</body>
<script type="text/javascript">
    //添加推荐层条件
    function add_recommend_level(that){
        var html = '<div class="add_recommend_level">' +
                '<span>销售额达到&nbsp;&nbsp;</span>' +
                '<input type="text" name="push[]" value="">' +
                '<span>&nbsp;&nbsp;,返&nbsp;</span>' +
                '<input type="text" name="return_numbers[]" value="">' +
                '<span class="zs"></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' +
                
                '<span><a onclick="del_recommend_level(this);">删除</a></span>' +
                '</div>';
        $(that).parent().parent().parent().append(html);
    }
    //删除推荐层条件
    function del_recommend_level(that){
        $(that).parent().parent().remove();
    }
    function alipay(fileurl_tmp)
    {
        /*alert(1);
        console.log(fileurl_tmp);*/
        $("#alicode").val(fileurl_tmp);
        $("#alipay_a").attr('href', fileurl_tmp);
        $("#alipay_i").attr('onmouseover', "layer.tips('<img src="+fileurl_tmp+">',this,{tips: [1, '#fff']});");
    }
    function wx(fileurl_tmp)
    {
       /* alert(1);
        console.log(fileurl_tmp);*/
        $("#wxcode").val(fileurl_tmp);
        $("#wx_a").attr('href', fileurl_tmp);
        $("#wx_i").attr('onmouseover', "layer.tips('<img src="+fileurl_tmp+">',this,{tips: [1, '#fff']});");
    }
</script>
</html>