<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:46:"./template/mobile/new/order\order_confirm.html";i:1551506937;s:40:"./template/mobile/new/public\header.html";i:1551506937;s:44:"./template/mobile/new/public\header_nav.html";i:1551506937;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>确认收货成功--<?php echo $tpshop_config['shop_info_store_title']; ?></title>
    <link rel="stylesheet" href="__STATIC__/css/style.css">
    <link rel="stylesheet" type="text/css" href="__STATIC__/css/iconfont.css"/>
    <script src="__STATIC__/js/jquery-3.1.1.min.js" type="text/javascript" charset="utf-8"></script>
    <!--<script src="__STATIC__/js/zepto-1.2.0-min.js" type="text/javascript" charset="utf-8"></script>-->
    <script src="__STATIC__/js/style.js" type="text/javascript" charset="utf-8"></script>
    <script src="__STATIC__/js/mobile-util.js" type="text/javascript" charset="utf-8"></script>
    <script src="__PUBLIC__/js/global.js"></script>
    <script src="__STATIC__/js/layer.js"  type="text/javascript" ></script>
    <script src="__STATIC__/js/swipeSlide.min.js" type="text/javascript" charset="utf-8"></script>
    <script src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>

    <script src="__STATIC__/assets/js/wxsdkcommon.js?v=1455"></script>
</head>
<script>
    var appId = "<?php echo $signPackage['appId']; ?>";
    var timestamp = "<?php echo $signPackage['timestamp']; ?>";
    var nonceStr = "<?php echo $signPackage['nonceStr']; ?>";
    var signature = "<?php echo $signPackage['signature']; ?>";
</script>
<body class="f3">

<div class="classreturn loginsignup ">
    <div class="content">
        <div class="ds-in-bl return">
            <a href="javascript:history.back(-1)"><img src="__STATIC__/images/return.png" alt="返回"></a>
        </div>
        <div class="ds-in-bl search center">
            <span>确认收货成功</span>
        </div>
        <div class="ds-in-bl menu">
          <!--  <a href="javascript:void(0);"><img src="__STATIC__/images/class1.png" alt="菜单"></a>-->
        </div>
    </div>
</div>
<div class="flool tpnavf">
    <div class="footer">
        <ul>
            <li>
                <a class="yello" href="<?php echo U('Index/index'); ?>">
                    <div class="icon">
                        <i class="icon-shouye iconfont"></i>
                        <p>首页</p>
                    </div>
                </a>
            </li>
            <li>
                <a href="<?php echo U('Goods/categoryList'); ?>">
                    <div class="icon">
                        <i class="icon-fenlei iconfont"></i>
                        <p>分类</p>
                    </div>
                </a>
            </li>
            <li>
                <!--<a href="shopcar.html">-->
                <a href="<?php echo U('Cart/index'); ?>">
                    <div class="icon">
                        <i class="icon-gouwuche iconfont"></i>
                        <p>购物车</p>
                    </div>
                </a>
            </li>
            <li>
                <a href="<?php echo U('User/index'); ?>">
                    <div class="icon">
                        <i class="icon-wode iconfont"></i>
                        <p>我的</p>
                    </div>
                </a>
            </li>
        </ul>
    </div>
</div>
<div class="euresucess">
    <img src="__STATIC__/images/sch.png"/>
    <p>确认收货成功</p>
</div>
<div class="sonfbst">
    <div class="maleri30">
        <span><i class="fbs"></i>立即发表评价晒图，最多可获得50积分</span>
    </div>
</div>
<div class="quedbox bg_white">
    <div class="fukcuid mae">
        <div class="maleri30">
            <?php if(is_array($order_goods['result']) || $order_goods['result'] instanceof \think\Collection || $order_goods['result'] instanceof \think\Paginator): if( count($order_goods['result'])==0 ) : echo "" ;else: foreach($order_goods['result'] as $key=>$good): ?>
                <div class="shopprice p">
                    <div class="img_or fl"><img src="<?php echo goods_thum_images($good[goods_id],100,100); ?>"></div>
                    <div class="fon_or fl">
                        <h2 class="similar-product-text"><a href="<?php echo U('Mobile/Goods/goodsInfo',array('id'=>$good[goods_id])); ?>"><?php echo $good[goods_name]; ?></a></h2>
                        <?php if($good['is_send'] == 1): ?>
                            <a class="compj" href="<?php echo U('Mobile/Order/add_comment',['rec_id'=>$good[rec_id]]); ?>">去评价</a>
                        <?php endif; if($good['is_send'] > 1): ?>
                            <a class="compj" href="<?php echo U('Mobile/Order/order_detail',array('id'=>I('id'))); ?>">已完成售后</a>
                        <?php endif; if($good['is_send'] == 0): ?>
                            <a class="compj">未发货</a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </div>
    </div>
</div>
</body>
</html>
