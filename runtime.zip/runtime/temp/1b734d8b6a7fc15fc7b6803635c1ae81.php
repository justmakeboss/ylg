<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:40:"./template/mobile/new/user\myqrcode.html";i:1551506979;s:40:"./template/mobile/new/common\header.html";i:1551506935;s:44:"./template/mobile/new/common\header_nav.html";i:1551506935;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=0">
    <link rel="stylesheet" type="text/css" href="__STATIC__/assets/weui/weui.css">
    <link rel="stylesheet" type="text/css" href="__STATIC__/assets/css/comm.css">
    <link rel="stylesheet" type="text/css" href="__STATIC__/assets/css/index.css">
    <link rel="stylesheet" type="text/css" href="__STATIC__/assets/js/lib/Swiper-3.4.2/swiper.min.css">
    <link rel="stylesheet" type="text/css" href="__STATIC__/assets/css/category.css">
    <script src="__STATIC__/assets/js/lib/jquery.min.2.1.3.js"></script>
    <script src="__STATIC__/assets/js/lib/weui.min.js"></script>
    <script src="__STATIC__/assets/js/comm.js"></script>
    <link rel="stylesheet" type="text/css" href="__STATIC__/assets/css/style.css">
    <script src="__PUBLIC__/js/global.js"></script>
    <script src="__STATIC__/js/layer.js"  type="text/javascript" ></script>
    <script src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>

    <script src="__STATIC__/assets/js/wxsdkcommon.js?v=1455"></script>

    <title><?php if($title): ?>我的分享码--<?php endif; ?><?php echo $tpshop_config['shop_info_store_title']; ?></title>
</head>
<script>
    var appId = "<?php echo $signPackage['appId']; ?>";
    var timestamp = "<?php echo $signPackage['timestamp']; ?>";
    var nonceStr = "<?php echo $signPackage['nonceStr']; ?>";
    var signature = "<?php echo $signPackage['signature']; ?>";
</script>
<body class="" <?php if(CONTROLLER_NAME == 'Index' and ACTION_NAME  == 'index'): ?> onload="countTime()" <?php endif; ?> >



<div class="page">
    <div class="page-hd">
        <div class="header">
            <div class="header-left">
                <a href=javascript:history.go(-1) class="left-arrow"></a>
            </div>
            <div class="header-title">我的分享码</div>
            <div class="header-right"><a href="#"></a> </div>
        </div>
    </div>

    <style>
        .avatar{
            border: 3px solid #fff;
            box-shadow: 0 3px 10px rgba(0,0,0,0.2);
            border-radius: 50%;
            margin-right: 10px;
            display: inline-block;
            width: 60px;
            height: 60px;
            vertical-align: middle;
        }
        .avatar img {
            float: left;
            display: block;
            width: 100%;
            height: 100%;
            border-radius: 50%;
        }
        .rwmbox {
            width: 300px;
            height: 300px;
            /* background-image: url("__STATIC__/assets/images/rwmbox_bg.png"); */
            background-size: 100% 100%;
            margin: 0 auto;
        }

        .rwmbox p {
            height: 0.666667rem;
            padding: 0.3rem 0.4rem;
        }

        .rwmbox .rwm_imgbox {
            width: 180px;
            height: 180px;
            margin: 0 auto;
            box-shadow: 1px rgba(255, 80, 0, 0.2);
        }

        .rwmbox .rwm_imgbox img {
            width: 100%;
            height: 100%;
        }
        p {
            display: block;
            -webkit-margin-before: 1em;
            -webkit-margin-after: 1em;
            -webkit-margin-start: 0px;
            -webkit-margin-end: 0px;
        }
        .fs26 {
            font-size: 14px;
        }
        .fs28 {
            font-size: 14px;
        }
        .rwmbox p {
            height: 80px;
            padding: 30px 40px;
            font-size: 14px;
        }

    </style>
</head>

    <div class="page-bd">
        <!-- 页面内容-->
        <!-- <div class="weui-flex" style="align-items: center; padding: 20px;">
            <div>
                <span class="avatar"><img src="<?php echo $user['head_pic']; ?>" alt=""></span>
            </div>
            <div  class="weui-flex__item"><span class="fs28">~<?php echo $user['nickname']; ?>~</span></div>
        </div> -->
        <div class="rwmbox">
            <p class="fs26"><!-- 我在<?php echo $tpshop_config['shop_info_store_title']; ?>，快来看看吧！ --></p>
            <div class="rwm_imgbox">
                <img src="<?php echo $qrcodeImg; ?>" alt="">
            </div>
        </div>
        <!-- <div class="fs26 mt20" style="padding:0 0.306667rem; color: #4c4c4c;">
            <p>1. 长按保存您的推广二维码或提供给您的代理扫描</p>
            <p>2. 复制您专属链接: “<span id="target"><?php echo $url; ?></span>”给您的代理</p>
            <p>3. 如果您的微信访问，请点击右上角，直接将分享给您的朋友或朋友圈</p>
        </div>
        <div class="weui-btn-area">
            <a href="javascript:;" id="copy_btn" data-clipboard-action="copy" data-clipboard-target="#target" class="weui-btn weui-btn_primary">点击复制链接</a>
        </div> -->
    </div>

</div>
<script src="https://cdn.jsdelivr.net/clipboard.js/1.5.12/clipboard.min.js"></script>

<script>
    window.onload=function (){
        var clipboard = new Clipboard('#copy_btn');
        clipboard.on('success', function(e) {
            $.toptip("复制成功！", 1500, 'success');
            e.clearSelection();
            console.log(e.clearSelection);
        });
    }
</script>
</body>
</html>