<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:51:"./application/admin/view2/systems\_admin\login.html";i:1551506738;}*/ ?>
<!DOCTYPE html>
<html lang="zh-cmn-Hans">
<head>
    <meta charset="utf-8">
    <title>登录页</title>
    <link rel="stylesheet" media="screen" href="__PUBLIC__/static/js/Swiper2/swiper.min.css">
    <link rel="stylesheet" media="screen" href="__PUBLIC__/static/css/zui.min.css">
    <link rel="stylesheet" media="screen" href="__PUBLIC__/static/css/login_new.css">
    <!--[if lte IE 8]>
    <script type="Text/Javascript" language="JavaScript">
        function detectBrowser()
        {
            var browser = navigator.appName
            if(navigator.userAgent.indexOf("MSIE")>0){
                var b_version = navigator.appVersion
                var version = b_version.split(";");
                var trim_Version = version[1].replace(/[ ]/g,"");
                if ((browser=="Netscape"||browser=="Microsoft Internet Explorer"))
                {
                    if(trim_Version == 'MSIE8.0' || trim_Version == 'MSIE7.0' || trim_Version == 'MSIE6.0'){
                        alert('请使用IE9.0版本以上进行访问');
                        return false;
                    }
                }
            }
        }
        detectBrowser();
    </script>
    <![endif]-->

</head>
<style>
    .chicuele {
        cursor: pointer;
        width:98px;
        position: RELATIVE;
        left: 18px;
        top: 3px;
        height: 37px;
        float: right;
        padding-right: 16px;
    }
    .yanz-ico{
        background: url(__PUBLIC__/static/images/yanz-ico.png);
        background-size: 100% 100%;
    }
    .error {
        font-size: 16px;
        color: #ea5813;
        width: 395px;
        font-weight: bold;
        background: white;
        padding: 0 5px;
        border-radius: 4px;
    }
</style>
<body style="overflow:hidden;">
<div id="login">
    <div class="l_box">
        <div class="l_box_sliders">
            <div id="myNiceCarousel" class="carousel slide" data-ride="carousel" data-interval="3000">
                <!-- 圆点指示器 -->
                <ol class="carousel-indicators">
                    <li data-target="#myNiceCarousel" data-slide-to="0" class="active"></li>
                    <li data-target="#myNiceCarousel" data-slide-to="1" class=""></li>
                </ol>
                <!-- 轮播项目 -->
                <div class="carousel-inner">
                    <div class="item active">
                        <img alt="First slide" src="__PUBLIC__/static/images/banner_1.png">
                    </div>
                    <div class="item">
                        <img alt="First slide" src="__PUBLIC__/static/images/banner_2.png">
                    </div>
                </div>
            </div>
        </div>
        <!--二维码登录-->
        <div class="er_box_form hide">
            <div class="lbf_hd">
                <p class="text">
                    <img src="__PUBLIC__/static/images/icon_1.png">
                    <span style="position: relative;top: -1px;">密码登录在这里</span>

                </p>
                <p class="erweima">
                    <img src="__PUBLIC__/static/images/icon_5.png" style="width: 37px;height: 37px;">
                </p>
            </div>
            <div class="lbf_bd">
                <div class="lbf_bd_tlt">
                    <span class="en">Login</span><i>|</i>
                    <span class="cn">商户登录</span>
                </div>
                <div class="lbf_bd_ctn">
                    <div class="er_img">
                        <img src="__PUBLIC__/static/images/erweima.png">
                    </div>
                    <div class="sys_img">
                        <img src="__PUBLIC__/static/images/sys.png">
                    </div>
                </div>
            </div>

        </div>

        <!--登录-->
        <div class="l_box_form" style="display: block;">
            <div class="lbf_hd">
                <p class="text">
                    <img src="__PUBLIC__/static/images/icon_1.png">
                    扫码登录更安全
                </p>
                <p class="erweima">
                    <img src="__PUBLIC__/static/images/icon_2.png">
                </p>
            </div>
            <div class="lbf_bd">
                <div class="lbf_bd_tlt">
                    <span class="en">Login</span><i>|</i>
                    <span class="cn">商户登录</span>
                </div>
                <div class="lbf_bd_ctn">
                    <!--<div class="tip-box">扫码登录更安全</div>-->
                    <form action="" name='theForm' id="theForm" method="post">
                        <input id="RawUrl" name="RawUrl" type="hidden" value="/">
                        <div class="b_input">
                            <input type="text" placeholder="请输入登录账号/手机号/昵称" name="username" id="userd">
                        </div>
                        <div class="b_input" style="background-image: url(__PUBLIC__/static/images/icon_4.jpg);">
                             <input type="password" placeholder="请输入密码"  name="password" id="passd">
                        </div>

                        <div class="input-box formText" style="border-bottom:none">
                            <?php if($verify_switch == 1): ?>
                                <input type="text" name="vertify" autocomplete="off" class="input-text chick_ue" value=""  placeholder="验证码" style="height: 36px;width: 160px;border-bottom: 1px solid #e5e5e5" />
                                <span class="yanz-ico"></span>
                                <img src="<?php echo U('Systems.Admin/vertify'); ?>" class="chicuele" id="imgVerify" alt="" onclick="fleshVerify()">
                            <?php endif; ?>
                        </div>
                        <div style="color:red;" id="loginError" title="输入错误">

                        </div>
                        <div class="b_checkbox">
                            <span><input type="checkbox" class="input_check" id="check3"><label for="check3"></label></span>
                            <label for="check3">记住密码</label>
                        </div>
                        <input class="btn_submit" id="LoginManage" type="button" value="登录">
                    </form>                    </div>
            </div>
            <div class="lbf_ft">
                <span class="wj_password">忘记密码<img src="__PUBLIC__/static/images/icon_right.png" alt=""></span>
            </div>
        </div>
        <!--忘记密码-->
        <div class="r_box_form hide" style="display: none;">
            <div class="lbf_bd">
                <div class="lbf_bd_tlt">
                    <span class="en">Login</span><i>|</i>
                    <span class="cn">忘记密码</span>
                </div>
                <div class="lbf_bd_ctn">
                    <form action="" name='theForm' id="theForm2" method="post">
                        <div class="b_input">
                            <span class="name">手机号码</span>
                            <input type="text" autocomplete="off" id="Phone" name="Phone" placeholder="请填写手机号码" phone="t" ele="phone" vali="" valiid="1"><label class="validate_label_prompt" id="valiid1" style="top: 41px; left: 0px; width: 200px;"></label>
                        </div>
                        <div class="b_input">
                            <span class="name">短信验证</span>
                            <input type="text" autocomplete="off" id="CodeNumber" name="CodeNumber" placeholder="请填写短信验证码" style="width: 150px;">
                            <span class="getvel get_code" onclick="send_msg()">获取验证</span>
                        </div>
                        <div class="b_input">
                            <span class="name">新密码</span>
                            <input type="password" autocomplete="off" style="width: 170px;" maxlength="16" placeholder="6~16位字符，不能包含空格" custom="t" ele="pad" id="password" vali="" valiid="2"><label class="validate_label_prompt" id="valiid2" style="top: 41px; left: 0px; width: 170px;"></label>
                                <span class="ck_password">

                                </span>
                        </div>
                        <div class="b_input">
                            <span class="name">再次输入</span>
                            <input type="password" autocomplete="new-password" style="width: 170px;" id="con_password" placeholder="请再次输入新密码" equally="#password" vali="" valiid="3"><label class="validate_label_prompt" id="valiid3" style="top: 41px; left: 0px; width: 170px;"></label>
                                <span class="ck_password">

                                </span>
                        </div>
                        <input type="button" id="UpdatePassword" class="btn_submit" value="确认">
                    </form>
                </div>
            </div>
            <div class="lbf_ft">
                <span class="host_login"><img src="__PUBLIC__/static/images/icon_left.png" alt="">返回登录</span>
            </div>
        </div>
        <!--成功状态-->
        <div class="success_box hide">
            <div>
                <img src="__PUBLIC__/static/images/icon_success.png">
                <p class="s_status">修改成功</p>
                <p class="s_text">已完成密码修改，请重新登录</p>
            </div>

        </div>

    </div>

</div>








<script type="text/javascript" src="__PUBLIC__/static/js/jquery.js"></script>
<script type="text/javascript" src="__PUBLIC__/static/js/zui.min.js"></script>
<script type="text/javascript">
    //进入忘记密码页
    $(".wj_password").click(function () {
        $(".r_box_form").fadeIn(400);
        $(".l_box_form").fadeOut(400)
    })
    //返回登录页
    $(".host_login").click(function () {
        $(".r_box_form").fadeOut(400);
        $(".l_box_form").fadeIn(400)
    })
    //二维码登录
    $(".l_box_form .erweima").click(function () {
        $(".l_box_form").hide();
        $(".er_box_form").fadeIn(400);

    })
    //密码登录
    $(".er_box_form .erweima").click(function () {
        $(".er_box_form").hide();
        $(".l_box_form").fadeIn(400);


    })
    //显示密码
    $(".ck_password").click(function () {

        if ($(this).hasClass("active")) {
            $(this).siblings("input").attr("type", "password")
        }
        else {
            $(this).siblings("input").attr("type", "text")
        }
        $(this).toggleClass("active");
    })

</script>

<script type="text/javascript">
    var startTime = 60;

    $(function () {

        $("#LoginManage").on("click", function () {
            var username = $("#UserName").val();
            var password = $("#PassWord").val();
            if (username == "" || password == "") {
                $("#loginError").html("您输入的账号或密码不正确！");
                return false;
            }
            var custid = $("#CustID").val();
            $.ajax({
                url: '/Login/CheckUser',
                type: 'POST',
                async: true,
                data: {
                    username: username,
                    password: password,
                    custid: custid
                },
                dataType: 'json',
                success: function (data) {
                    if (data) {
                        $("#loginError").html("");
                        $("#LoginFrom").submit();
                    } else {
                        $("#loginError").html("您输入的账号或密码不正确！");
                    }
                }, error: function (a,b) {
                }
            });
        });

        //获取验证
        $(".getvel").on("click", function () {
            var Phone = $("#Phone").val();
            var custid = $("#CustID").val();

            var bool = $(".getvel").hasClass("get_code");
            if (!bool) {
                return;
            }
            if (!(/^1[3|4|5|8][0-9]\d{4,8}$/.test(Phone))) {
                $.wmessage("请输入正确的手机号码！", 3);
                return;
            }

            $.ajax({
                url: '/SMS/LoginSendAuthentication',
                type: 'POST',
                async: true,
                data: {
                    phone: Phone,
                    custId: custid
                },
                dataType: 'json',
                success: function (data) {
                    if (data == 'success') {
                        startTime = 60;
                        SetInterval();
                        $(".getvel").removeClass("get_code");
                    } else {
                        $.wmessage(data, 3);
                    }
                }, error: function (a, b) {
                    $.wmessage("服务器请求失败！", 3);
                }
            });
        });


        //修改密码
        $("#UpdatePassword").on("click", function () {

            var phone = $("#Phone").val();
            var custid = $("#CustID").val();
            var code = $("#CodeNumber").val();
            var password = $("#password").val();
            var con_password = $("#con_password").val();

            if (!(/^1[3|4|5|8][0-9]\d{4,8}$/.test(phone))) {
                $.wmessage("请输入正确的手机号码！", 3);
                return;
            }
            if (code == "") {
                $.wmessage("请输入验证码！", 3);
                return;
            }

            if (password.length < 6 || password.length > 16 || !(password.indexOf(" ") == -1)) {
                $.wmessage("6~16位字符，不能包含空格！", 3);
                return;
            }
            if (password != con_password) {
                $.wmessage("输入的两次密码不一致！", 3);
                return;
            }

            $.ajax({
                url: '/Login/LoginUpdatePassword',
                type: 'POST',
                data: {
                    Phone: phone,
                    CustID: custid,
                    Code: code,
                    Password: password
                },
                dataType: 'json',
                success: function (data) {
                    if (data == "success") {
                        $(".l_box_form").css("display", "none");
                        $(".r_box_form").css("display", "none");
                        $(".success_box").removeClass("hide");
                        setTimeout(function () {
                            window.location.reload();
                        }, 2000)

                    } else {
                        $.wmessage(data, 3);
                    }
                }, error: function (a, b) {
                    $.wmessage("服务器请求失败！", 3);
                }
            });

        });

    });

    function SetInterval() {
        //验证码时间倒计时
        var RTime = setInterval(function () {
            if (startTime > 0) {
                startTime = startTime - 1;
                $(".getvel").html("重发(" + startTime + "s)");
            } else {
                clearInterval(RTime);
                $(".getvel").html("重新发送");
                $(".getvel").addClass("get_code");
            }
        }, 1000);
    }
</script>

<script type="text/javascript">
    if (self != top) {
        window.top.location.replace(self.location); //打开自己网站的页面
    }
</script>
<script>


    function fleshVerify(){
        $('#imgVerify').attr('src','/index.php?m=Admin&c=Systems.Admin&a=vertify&r='+Math.floor(Math.random()*100));//重载验证码
    }

    $(function(){
        $('#theForm  #LoginManage').on('click',function(){
            var username=true;
            var password=true;
            var vertify=true;

            if($('#theForm input[name=username]').val() == ''){
                $('#loginError').html('<span class="error">用户名不能为空!</span>');
                $('#theForm input[name=username]').focus();
                username = false;
                return false;
            }
            if($('#theForm input[name=password]').val() == ''){
                $('#loginError').html('<span class="error">密码不能为空!</span>');
                $('#theForm input[name=password]').focus();
                password = false;
                return false;
            }

            if($('#theForm input[name=vertify]').val() == ''){
                $('#loginError').html('<span class="error">验证码不能为空!</span>');
                $('#theForm input[name=vertify]').focus();
                vertify = false;
                return false;
            }

            if(vertify && $('#theForm input[name=username]').val() != '' && $('#theForm input[name=password]').val() != ''){
                $.ajax({
                    async:false,
                    url:'/index.php?m=Admin&c=Systems.Admin&a=login&t='+Math.random(),
                    data:{'username':$('#theForm input[name=username]').val(),'password':$('#theForm input[name=password]').val(),vertify:$('#theForm input[name=vertify]').val()},
                    type:'post',
                    dataType:'json',
                    success:function(res){
                        if(res.status != 1){
                            $('#loginError').html('<span class="error">'+res.msg+'!</span>');
                            fleshVerify();
                            username=false;
                            password=false;
                            return false;
                        }else{
                            top.location.href = res.url;
                        }
                    },
                    error : function(XMLHttpRequest, textStatus, errorThrown) {
                        $('#loginError').html('<span class="error">网络失败，请刷新页面后重试!</span>');
                    }
                });
            }else{
                return false;
            }


        })
    })
</script>
<script>
    function send_msg(){
        var phone = $('input[name="Phone"]').val();
        if (phone == '' || phone == null || phone == undefined) {
            layer.msg('请填写手机号码！', {icon: 1});
        }

    }
</script>
</body>
</html>