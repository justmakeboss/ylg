<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:38:"./template/mobile/new/index\index.html";i:1551594772;s:44:"./template/mobile/new/common\layout_nav.html";i:1551506935;s:40:"./template/mobile/new/common\header.html";i:1551506935;s:44:"./template/mobile/new/common\footer_nav.html";i:1551506935;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=0">
    <link rel="stylesheet" type="text/css" href="__STATIC__/assets/weui/weui.css">
    <link rel="stylesheet" type="text/css" href="__STATIC__/assets/css/comm.css">
    <link rel="stylesheet" type="text/css" href="__STATIC__/assets/css/index.css">
    <link rel="stylesheet" type="text/css" href="__STATIC__/assets/js/lib/Swiper-3.4.2/swiper.min.css">
    <link rel="stylesheet" type="text/css" href="__STATIC__/assets/css/category.css">
    <script src="__STATIC__/assets/js/lib/jquery.min.2.1.3.js"></script>
    <script src="__STATIC__/assets/js/lib/weui.min.js"></script>
    <script src="__STATIC__/assets/js/comm.js"></script>
    <link rel="stylesheet" type="text/css" href="__STATIC__/assets/css/style.css">
    <script src="__PUBLIC__/js/global.js"></script>
    <script src="__STATIC__/js/layer.js"  type="text/javascript" ></script>
    <script src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>

    <script src="__STATIC__/assets/js/wxsdkcommon.js?v=1455"></script>

    <title><?php if($title): ?><?php echo $title; ?>--<?php endif; ?><?php echo $tpshop_config['shop_info_store_title']; ?></title>
</head>
<script>
    var appId = "<?php echo $signPackage['appId']; ?>";
    var timestamp = "<?php echo $signPackage['timestamp']; ?>";
    var nonceStr = "<?php echo $signPackage['nonceStr']; ?>";
    var signature = "<?php echo $signPackage['signature']; ?>";
</script>
<body class="[body]" <?php if(CONTROLLER_NAME == 'Index' and ACTION_NAME  == 'index'): ?> onload="countTime()" <?php endif; ?> >




<!-- <div class="page-hd">
    <div class="search-bar">
        <div class="weui-flex">
            <a href="<?php echo U('Goods/categoryList'); ?>" class="fenlei"></a>
            <div class="weui-flex__item search-input">
                <form action=""  method="post">
                    <a href="<?php echo U('Goods/ajaxSearch'); ?>"><input type="search" name="q" id="search_text" class="search_text"   value="" placeholder="搜索您想要的商品名称">
                <a href="" class="search-icon"></a></a>
                </form>
            </div>
        </div>
    </div>
</div> -->

<link rel="stylesheet" href="__STATIC__/assets/assets/css/all.css"/>
<div class="page-bd">
    <div class="swiper-container index-banner">
        <div class="swiper-wrapper">
            <?php $pid =513283;$ad_position = M("ad_position")->cache(true,TPSHOP_CACHE_TIME)->column("position_id,position_name,ad_width,ad_height","position_id");$result = M("ad")->where("pid=$pid  and enabled = 1 and start_time < 1551592800 and end_time > 1551592800 ")->order("orderby desc")->cache(true,TPSHOP_CACHE_TIME)->limit("5")->select();
if(is_array($ad_position) && !in_array($pid,array_keys($ad_position)) && $pid)
{
  M("ad_position")->insert(array(
         "position_id"=>$pid,
         "position_name"=>CONTROLLER_NAME."页面自动增加广告位 $pid ",
         "is_open"=>1,
         "position_desc"=>CONTROLLER_NAME."页面",
  ));
  delFile(RUNTIME_PATH); // 删除缓存
  \think\Cache::clear();  
}


$c = 5- count($result); //  如果要求数量 和实际数量不一样 并且编辑模式
if($c > 0 && I("get.edit_ad"))
{
    for($i = 0; $i < $c; $i++) // 还没有添加广告的时候
    {
      $result[] = array(
          "ad_code" => "/public/images/not_adv.jpg",
          "ad_link" => "/index.php?m=Admin&c=Ad&a=ad&pid=$pid",
          "title"   =>"暂无广告图片",
          "not_adv" => 1,
          "target" => 0,
      );  
    }
}
foreach($result as $key=>$v):       
    
    $v[position] = $ad_position[$v[pid]]; 
    if(I("get.edit_ad") && $v[not_adv] == 0 )
    {
        $v[style] = "filter:alpha(opacity=50); -moz-opacity:0.5; -khtml-opacity: 0.5; opacity: 0.5"; // 广告半透明的样式
        $v[ad_link] = "/index.php?m=Admin&c=Ad&a=ad&act=edit&ad_id=$v[ad_id]";        
        $v[title] = $ad_position[$v[pid]][position_name]."===".$v[ad_name];
        $v[target] = 0;
    }
    ?>
                <div class="swiper-slide"> <a href="<?php echo $v['ad_link']; ?>"><img src="<?php echo $v[ad_code]; ?>" style="width: 100%;height: 180px"/> </a></div>
            <?php endforeach; ?>
        </div>
        <!-- Add Pagination -->
        <div class="swiper-pagination-wrap"><div class="swiper-pagination"></div></div>
    </div>
    <img src="__STATIC__/assets/images/index01.jpg" style="width: 100%;"/>
    <div class="weui-panel">
        <div class="weui-panel__bd">
            <div class="weui-flex">
                <div class="weui-flex__item">
                    <a href="<?php echo U('Index/retail'); ?>" class="nav-icon-link">
                        <div class="weui-grid__icon" style="width: 60%;height: 100%">
                            <img src="__STATIC__/assets/images/icon1.png" alt="">
                        </div>
                        <p class="weui-grid__label">活动区</p>
                    </a>
                </div>
                <div class="weui-flex__item">
                    <a href="<?php echo U('Index/agent'); ?>" class="nav-icon-link">
                        <!-- <a href="<?php echo U('hot/goods_list'); ?>" class="nav-icon-link"> -->
                        <div class="weui-grid__icon" style="width: 60%;height: 100%">
                            <img src="__STATIC__/assets/images/icon2.png" alt="">
                        </div>
                        <p class="weui-grid__label">批发区</p>
                    </a>
                </div>

                <div class="weui-flex__item">
                    <a href="#" class="nav-icon-link" onclick="layer.open({content:'功能暂未开放',skin: 'msg',time: 2 })" >
                        <div class="weui-grid__icon" style="width: 60%;height: 100%">
                            <img src="__STATIC__/assets/images/icon3.png" alt="">
                        </div>
                        <p class="weui-grid__label">周排行</p>
                    </a>
                </div>
                <div class="weui-flex__item">
                    <a href="#" class="nav-icon-link" onclick="layer.open({content:'功能暂未开放',skin: 'msg',time: 2 })" >
                        <div class="weui-grid__icon" style="width: 60%;height: 100%">
                            <img src="__STATIC__/assets/images/icon3.png" alt="">                        </div>
                        <p class="weui-grid__label">月排行</p>
                    </a>
                </div>
                <?php if(false):?>
                <div class="weui-flex__item">
                    <a href="<?php echo U('Index/ordinary'); ?>" class="nav-icon-link">
                        <div class="weui-grid__icon" style="width: 60%;height: 100%">
                            <img src="__STATIC__/assets/images/icon3.png" alt="">
                        </div>
                        <p class="weui-grid__label">普通专区</p>
                    </a>
                </div>
                <div class="weui-flex__item">
                    <a href="#" class="nav-icon-link" onclick="layer.open({content:'功能暂未开放',skin: 'msg',time: 2 })" >
                        <div class="weui-grid__icon" style="width: 60%;height: 100%">
                            <img src="__STATIC__/assets/images/icon4.png" alt="">
                        </div>
                        <p class="weui-grid__label">万家连锁</p>
                    </a>
                </div>
                <?php endif;?>
            </div>
        </div>
            <?php if(false):?>
         <div class="weui-panel__bd">
            <div class="weui-flex">
               <div class="weui-flex__item">
                    <a href="<?php echo U('activity/todaygoods'); ?>" class="nav-icon-link">
                        <div class="weui-grid__icon" style="width: 60%;height: 100%" center>
                            <img src="__STATIC__/assets/images/icon8.png">
                        </div>
                        <p class="weui-grid__label">新品上市</p>
                    </a>
                </div>
                <div class="weui-flex__item">
                    <a href="<?php echo U('hot/goods_list'); ?>" class="nav-icon-link">
                        <!-- <a href="<?php echo U('hot/goods_list'); ?>" class="nav-icon-link"> -->
                        <div class="weui-grid__icon" style="width: 60%;height: 100%">
                            <img src="__STATIC__/assets/images/icon6.png" alt="">
                        </div>
                        <p class="weui-grid__label">超值热卖</p>
                    </a>
                </div>

                 <div class="weui-flex__item">
                    <a href="<?php echo U('Index/recommend'); ?>" class="nav-icon-link">
                        <div class="weui-grid__icon" style="width: 60%;height: 100%">
                            <img src="__STATIC__/assets/images/icon5.png" alt="">
                        </div>
                        <p class="weui-grid__label">精品推荐</p>
                    </a>
                </div>
                <div class="weui-flex__item">
                    <a href="<?php echo U('activity/flash_sale_list'); ?>" class="nav-icon-link">
                        <div class="weui-grid__icon" style="width: 60%;height: 100%">
                            <img src="__STATIC__/assets/images/icon7.png" alt="">
                        </div>
                        <p class="weui-grid__label">秒杀专区</p>
                    </a>
                </div>
            </div>
        </div>
        <?php endif;?>
    </div>
    <!-- <div class="weui-panel">
        <div class="weui-panel__hd after-left__0">
            <h3 class="index-panel__title"><i class="icon-hot"></i><span>热门专场</span></h3>
        </div>
        <div class="weui-panel__bd">
            <div class="weui-flex vux-1px-b">
                <div class="weui-flex__item">
                    <?php $pid =513284;$ad_position = M("ad_position")->cache(true,TPSHOP_CACHE_TIME)->column("position_id,position_name,ad_width,ad_height","position_id");$result = M("ad")->where("pid=$pid  and enabled = 1 and start_time < 1551592800 and end_time > 1551592800 ")->order("orderby desc")->cache(true,TPSHOP_CACHE_TIME)->limit("1")->select();
if(is_array($ad_position) && !in_array($pid,array_keys($ad_position)) && $pid)
{
  M("ad_position")->insert(array(
         "position_id"=>$pid,
         "position_name"=>CONTROLLER_NAME."页面自动增加广告位 $pid ",
         "is_open"=>1,
         "position_desc"=>CONTROLLER_NAME."页面",
  ));
  delFile(RUNTIME_PATH); // 删除缓存
  \think\Cache::clear();  
}


$c = 1- count($result); //  如果要求数量 和实际数量不一样 并且编辑模式
if($c > 0 && I("get.edit_ad"))
{
    for($i = 0; $i < $c; $i++) // 还没有添加广告的时候
    {
      $result[] = array(
          "ad_code" => "/public/images/not_adv.jpg",
          "ad_link" => "/index.php?m=Admin&c=Ad&a=ad&pid=$pid",
          "title"   =>"暂无广告图片",
          "not_adv" => 1,
          "target" => 0,
      );  
    }
}
foreach($result as $key=>$v):       
    
    $v[position] = $ad_position[$v[pid]]; 
    if(I("get.edit_ad") && $v[not_adv] == 0 )
    {
        $v[style] = "filter:alpha(opacity=50); -moz-opacity:0.5; -khtml-opacity: 0.5; opacity: 0.5"; // 广告半透明的样式
        $v[ad_link] = "/index.php?m=Admin&c=Ad&a=ad&act=edit&ad_id=$v[ad_id]";        
        $v[title] = $ad_position[$v[pid]][position_name]."===".$v[ad_name];
        $v[target] = 0;
    }
    ?>
                        <a href="<?php echo $v[ad_link]; ?>" class="graphic__item vux-1px-r"><img src="<?php echo $v[ad_code]; ?>" style="width:100%"/></a>
                    <?php endforeach; ?>
                </div>
                <div class="weui-flex__item">
                    <?php $pid =513285;$ad_position = M("ad_position")->cache(true,TPSHOP_CACHE_TIME)->column("position_id,position_name,ad_width,ad_height","position_id");$result = M("ad")->where("pid=$pid  and enabled = 1 and start_time < 1551592800 and end_time > 1551592800 ")->order("orderby desc")->cache(true,TPSHOP_CACHE_TIME)->limit("2")->select();
if(is_array($ad_position) && !in_array($pid,array_keys($ad_position)) && $pid)
{
  M("ad_position")->insert(array(
         "position_id"=>$pid,
         "position_name"=>CONTROLLER_NAME."页面自动增加广告位 $pid ",
         "is_open"=>1,
         "position_desc"=>CONTROLLER_NAME."页面",
  ));
  delFile(RUNTIME_PATH); // 删除缓存
  \think\Cache::clear();  
}


$c = 2- count($result); //  如果要求数量 和实际数量不一样 并且编辑模式
if($c > 0 && I("get.edit_ad"))
{
    for($i = 0; $i < $c; $i++) // 还没有添加广告的时候
    {
      $result[] = array(
          "ad_code" => "/public/images/not_adv.jpg",
          "ad_link" => "/index.php?m=Admin&c=Ad&a=ad&pid=$pid",
          "title"   =>"暂无广告图片",
          "not_adv" => 1,
          "target" => 0,
      );  
    }
}
foreach($result as $key=>$v):       
    
    $v[position] = $ad_position[$v[pid]]; 
    if(I("get.edit_ad") && $v[not_adv] == 0 )
    {
        $v[style] = "filter:alpha(opacity=50); -moz-opacity:0.5; -khtml-opacity: 0.5; opacity: 0.5"; // 广告半透明的样式
        $v[ad_link] = "/index.php?m=Admin&c=Ad&a=ad&act=edit&ad_id=$v[ad_id]";        
        $v[title] = $ad_position[$v[pid]][position_name]."===".$v[ad_name];
        $v[target] = 0;
    }
    ?>
                        <a href="<?php echo $v[ad_link]; ?>"  class="graphic__item vux-1px-b"><img src="<?php echo $v[ad_code]; ?>" style="width:100%"/></a>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="weui-flex vux-1px-b">
                <div class="weui-flex__item">
                    <?php $pid =513286;$ad_position = M("ad_position")->cache(true,TPSHOP_CACHE_TIME)->column("position_id,position_name,ad_width,ad_height","position_id");$result = M("ad")->where("pid=$pid  and enabled = 1 and start_time < 1551592800 and end_time > 1551592800 ")->order("orderby desc")->cache(true,TPSHOP_CACHE_TIME)->limit("1")->select();
if(is_array($ad_position) && !in_array($pid,array_keys($ad_position)) && $pid)
{
  M("ad_position")->insert(array(
         "position_id"=>$pid,
         "position_name"=>CONTROLLER_NAME."页面自动增加广告位 $pid ",
         "is_open"=>1,
         "position_desc"=>CONTROLLER_NAME."页面",
  ));
  delFile(RUNTIME_PATH); // 删除缓存
  \think\Cache::clear();  
}


$c = 1- count($result); //  如果要求数量 和实际数量不一样 并且编辑模式
if($c > 0 && I("get.edit_ad"))
{
    for($i = 0; $i < $c; $i++) // 还没有添加广告的时候
    {
      $result[] = array(
          "ad_code" => "/public/images/not_adv.jpg",
          "ad_link" => "/index.php?m=Admin&c=Ad&a=ad&pid=$pid",
          "title"   =>"暂无广告图片",
          "not_adv" => 1,
          "target" => 0,
      );  
    }
}
foreach($result as $key=>$v):       
    
    $v[position] = $ad_position[$v[pid]]; 
    if(I("get.edit_ad") && $v[not_adv] == 0 )
    {
        $v[style] = "filter:alpha(opacity=50); -moz-opacity:0.5; -khtml-opacity: 0.5; opacity: 0.5"; // 广告半透明的样式
        $v[ad_link] = "/index.php?m=Admin&c=Ad&a=ad&act=edit&ad_id=$v[ad_id]";        
        $v[title] = $ad_position[$v[pid]][position_name]."===".$v[ad_name];
        $v[target] = 0;
    }
    ?>
                        <a href="<?php echo $v[ad_link]; ?>" class="graphic__item vux-1px-r"><img src="<?php echo $v[ad_code]; ?>" style="width:100%"/></a>
                    <?php endforeach; ?>
                </div>
                <div class="weui-flex__item">
                    <?php $pid =513287;$ad_position = M("ad_position")->cache(true,TPSHOP_CACHE_TIME)->column("position_id,position_name,ad_width,ad_height","position_id");$result = M("ad")->where("pid=$pid  and enabled = 1 and start_time < 1551592800 and end_time > 1551592800 ")->order("orderby desc")->cache(true,TPSHOP_CACHE_TIME)->limit("2")->select();
if(is_array($ad_position) && !in_array($pid,array_keys($ad_position)) && $pid)
{
  M("ad_position")->insert(array(
         "position_id"=>$pid,
         "position_name"=>CONTROLLER_NAME."页面自动增加广告位 $pid ",
         "is_open"=>1,
         "position_desc"=>CONTROLLER_NAME."页面",
  ));
  delFile(RUNTIME_PATH); // 删除缓存
  \think\Cache::clear();  
}


$c = 2- count($result); //  如果要求数量 和实际数量不一样 并且编辑模式
if($c > 0 && I("get.edit_ad"))
{
    for($i = 0; $i < $c; $i++) // 还没有添加广告的时候
    {
      $result[] = array(
          "ad_code" => "/public/images/not_adv.jpg",
          "ad_link" => "/index.php?m=Admin&c=Ad&a=ad&pid=$pid",
          "title"   =>"暂无广告图片",
          "not_adv" => 1,
          "target" => 0,
      );  
    }
}
foreach($result as $key=>$v):       
    
    $v[position] = $ad_position[$v[pid]]; 
    if(I("get.edit_ad") && $v[not_adv] == 0 )
    {
        $v[style] = "filter:alpha(opacity=50); -moz-opacity:0.5; -khtml-opacity: 0.5; opacity: 0.5"; // 广告半透明的样式
        $v[ad_link] = "/index.php?m=Admin&c=Ad&a=ad&act=edit&ad_id=$v[ad_id]";        
        $v[title] = $ad_position[$v[pid]][position_name]."===".$v[ad_name];
        $v[target] = 0;
    }
    ?>
                        <a href="<?php echo $v[ad_link]; ?>"  class="graphic__item vux-1px-b"><img src="<?php echo $v[ad_code]; ?>" style="width:100%"/></a>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="weui-flex">
                <?php $pid =0;$ad_position = M("ad_position")->cache(true,TPSHOP_CACHE_TIME)->column("position_id,position_name,ad_width,ad_height","position_id");$result = M("ad")->where("pid=$pid  and enabled = 1 and start_time < 1551592800 and end_time > 1551592800 ")->order("orderby desc")->cache(true,TPSHOP_CACHE_TIME)->limit("2")->select();
if(is_array($ad_position) && !in_array($pid,array_keys($ad_position)) && $pid)
{
  M("ad_position")->insert(array(
         "position_id"=>$pid,
         "position_name"=>CONTROLLER_NAME."页面自动增加广告位 $pid ",
         "is_open"=>1,
         "position_desc"=>CONTROLLER_NAME."页面",
  ));
  delFile(RUNTIME_PATH); // 删除缓存
  \think\Cache::clear();  
}


$c = 2- count($result); //  如果要求数量 和实际数量不一样 并且编辑模式
if($c > 0 && I("get.edit_ad"))
{
    for($i = 0; $i < $c; $i++) // 还没有添加广告的时候
    {
      $result[] = array(
          "ad_code" => "/public/images/not_adv.jpg",
          "ad_link" => "/index.php?m=Admin&c=Ad&a=ad&pid=$pid",
          "title"   =>"暂无广告图片",
          "not_adv" => 1,
          "target" => 0,
      );  
    }
}
foreach($result as $key=>$v):       
    
    $v[position] = $ad_position[$v[pid]]; 
    if(I("get.edit_ad") && $v[not_adv] == 0 )
    {
        $v[style] = "filter:alpha(opacity=50); -moz-opacity:0.5; -khtml-opacity: 0.5; opacity: 0.5"; // 广告半透明的样式
        $v[ad_link] = "/index.php?m=Admin&c=Ad&a=ad&act=edit&ad_id=$v[ad_id]";        
        $v[title] = $ad_position[$v[pid]][position_name]."===".$v[ad_name];
        $v[target] = 0;
    }
    ?>
                    <div class="weui-flex__item vux-1px-r">
                        <a href="<?php echo $v[ad_link]; ?>" class="graphic__item">
                            <img src="<?php echo $v[ad_code]; ?>" style="width:100%"/>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div> -->
    <!-- <?php $pid =0;$ad_position = M("ad_position")->cache(true,TPSHOP_CACHE_TIME)->column("position_id,position_name,ad_width,ad_height","position_id");$result = M("ad")->where("pid=$pid  and enabled = 1 and start_time < 1551592800 and end_time > 1551592800 ")->order("orderby desc")->cache(true,TPSHOP_CACHE_TIME)->limit("1")->select();
if(is_array($ad_position) && !in_array($pid,array_keys($ad_position)) && $pid)
{
  M("ad_position")->insert(array(
         "position_id"=>$pid,
         "position_name"=>CONTROLLER_NAME."页面自动增加广告位 $pid ",
         "is_open"=>1,
         "position_desc"=>CONTROLLER_NAME."页面",
  ));
  delFile(RUNTIME_PATH); // 删除缓存
  \think\Cache::clear();  
}


$c = 1- count($result); //  如果要求数量 和实际数量不一样 并且编辑模式
if($c > 0 && I("get.edit_ad"))
{
    for($i = 0; $i < $c; $i++) // 还没有添加广告的时候
    {
      $result[] = array(
          "ad_code" => "/public/images/not_adv.jpg",
          "ad_link" => "/index.php?m=Admin&c=Ad&a=ad&pid=$pid",
          "title"   =>"暂无广告图片",
          "not_adv" => 1,
          "target" => 0,
      );  
    }
}
foreach($result as $key=>$v):       
    
    $v[position] = $ad_position[$v[pid]]; 
    if(I("get.edit_ad") && $v[not_adv] == 0 )
    {
        $v[style] = "filter:alpha(opacity=50); -moz-opacity:0.5; -khtml-opacity: 0.5; opacity: 0.5"; // 广告半透明的样式
        $v[ad_link] = "/index.php?m=Admin&c=Ad&a=ad&act=edit&ad_id=$v[ad_id]";        
        $v[title] = $ad_position[$v[pid]][position_name]."===".$v[ad_name];
        $v[target] = 0;
    }
    ?>
        <div class="ad-banner" style="margin:10px 0;">
            <a href="<?php echo $v[ad_link]; ?>">
                <img src="<?php echo $v[ad_code]; ?>" alt="" style="width: 100%">
            </a>
        </div>
    <?php endforeach; ?> -->
    <div class="weui-flex__item">
        <?php $pid =513288;$ad_position = M("ad_position")->cache(true,TPSHOP_CACHE_TIME)->column("position_id,position_name,ad_width,ad_height","position_id");$result = M("ad")->where("pid=$pid  and enabled = 1 and start_time < 1551592800 and end_time > 1551592800 ")->order("orderby desc")->cache(true,TPSHOP_CACHE_TIME)->limit("1")->select();
if(is_array($ad_position) && !in_array($pid,array_keys($ad_position)) && $pid)
{
  M("ad_position")->insert(array(
         "position_id"=>$pid,
         "position_name"=>CONTROLLER_NAME."页面自动增加广告位 $pid ",
         "is_open"=>1,
         "position_desc"=>CONTROLLER_NAME."页面",
  ));
  delFile(RUNTIME_PATH); // 删除缓存
  \think\Cache::clear();  
}


$c = 1- count($result); //  如果要求数量 和实际数量不一样 并且编辑模式
if($c > 0 && I("get.edit_ad"))
{
    for($i = 0; $i < $c; $i++) // 还没有添加广告的时候
    {
      $result[] = array(
          "ad_code" => "/public/images/not_adv.jpg",
          "ad_link" => "/index.php?m=Admin&c=Ad&a=ad&pid=$pid",
          "title"   =>"暂无广告图片",
          "not_adv" => 1,
          "target" => 0,
      );  
    }
}
foreach($result as $key=>$v):       
    
    $v[position] = $ad_position[$v[pid]]; 
    if(I("get.edit_ad") && $v[not_adv] == 0 )
    {
        $v[style] = "filter:alpha(opacity=50); -moz-opacity:0.5; -khtml-opacity: 0.5; opacity: 0.5"; // 广告半透明的样式
        $v[ad_link] = "/index.php?m=Admin&c=Ad&a=ad&act=edit&ad_id=$v[ad_id]";        
        $v[title] = $ad_position[$v[pid]][position_name]."===".$v[ad_name];
        $v[target] = 0;
    }
    ?>
            <a href="<?php echo $v[ad_link]; ?>"  class="graphic__item vux-1px-b"><img src="<?php echo $v[ad_code]; ?>" style="width:100%"/></a>
        <?php endforeach; ?>
    </div>
<div class="weui-panel">
    <div class="weui-panel__hd after-left__0">
        <a href="<?php echo U('Index/retail'); ?>"><h3 class="index-panel__title"></i><span style="float: left">活动专区</span><span style="float: right"> 更多> </span></h3></a>
    </div>
</div>

<div class="floor guesslike groupquess dic">
    <div class="likeshop">
        <ul>

<?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): if( count($list)==0 ) : echo "" ;else: foreach($list as $k=>$v): ?>
    <li style="margin-bottom: 2%; list-style:none;width: 49%; <?php if($k%2==0): ?>margin-right: 2%<?php endif; ?>" >
        <a href="<?php echo U('Mobile/Goods/goodsInfo',array('id'=>$v[goods_id])); ?>">
            <div class="similer-product">
                <div class="zjj close">
                    <img src="<?php echo goods_thum_images($v['goods_id'],200,200); ?>">
                </div>
                <span class="similar-product-text"><?php echo $v[goods_name]; ?></span>
                <span class="similar-product-price">
                    ¥<span class="big-price"><?php echo $v[shop_price]; ?>元</span>
                    <span class="fr sg_g_time last_g_time" id="jstimerBox<?php echo $v[goods_id]; ?>"></span>
                </span>
            </div>
        </a>
    </li>
<?php endforeach; endif; else: echo "" ;endif; ?>

        </ul>
    </div>
</div>

<div class="weui-panel" style="margin-bottom: 10px;">
    <div class="weui-panel__hd after-left__0">
        <a href="<?php echo U('Index/agent'); ?>"><h3 class="index-panel__title"><span style="float: left">批发区</span><span style="float: right"> 更多> </span></h3></a>
    </div>
</div>

<div class="floor guesslike groupquess dic">
    <div class="likeshop2">
        <ul>
<?php if(is_array($list2) || $list2 instanceof \think\Collection || $list2 instanceof \think\Paginator): if( count($list2)==0 ) : echo "" ;else: foreach($list2 as $k2=>$v2): ?>
    <li style="margin-bottom: 2%; list-style:none;width: 49%; <?php if($k2%2==0): ?>margin-right: 2%<?php endif; ?>" >
        <a href="<?php echo U('Mobile/Goods/goodsInfo',array('id'=>$v2[goods_id])); ?>">
            <div class="similer-product">
                <div class="zjj close">
                    <img src="<?php echo goods_thum_images($v2['goods_id'],200,200); ?>">
                </div>
                <input type="hidden" id="agentend_time<?php echo $k2; ?>" value="<?php echo $v2['agentend_time']; ?>">
                <div class="bet-time fs-22 color-f9">
                        <div class="time-ol" style="padding: 10px">
                          <span class="opwe _d<?php echo $k2; ?>">00</span><span class="_h<?php echo $k2; ?>">00</span> <span class="_m<?php echo $k2; ?>">00</span><span class="_s<?php echo $k2; ?>">00</span>
                        </div>
                   </div>
                <span class="similar-product-text"><?php echo $v2[goods_name]; ?></span>
                <span class="similar-product-price">
                    ¥<span class="big-price"><?php echo $v2[shop_price]; ?>元</span>
                    <span class="fr sg_g_time last_g_time" id="jstimerBox<?php echo $v2[goods_id]; ?>"></span>
                </span>
            </div>
        </a>
    </li>
<?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
    </div>
</div>

<div class="weui-panel" style="margin-bottom: 10px">
    <div class="weui-panel__hd after-left__0">
        <a href="<?php echo U('Index/ordinary'); ?>"><h3 class="index-panel__title"><span style="float: left">普通专区</span><span style="float: right"> 更多> </span></h3></a>
    </div>
</div>

<div class="floor guesslike groupquess dic">
    <div class="likeshop3">
        <ul>
<?php if(is_array($list3) || $list3 instanceof \think\Collection || $list3 instanceof \think\Paginator): if( count($list3)==0 ) : echo "" ;else: foreach($list3 as $k3=>$v3): ?>
    <li style="margin-bottom: 2%; list-style:none;width: 49%; <?php if($k3%2==0): ?>margin-right: 2%<?php endif; ?>" >
        <a href="<?php echo U('Mobile/Goods/goodsInfo',array('id'=>$v3[goods_id])); ?>">
            <div class="similer-product">
                <div class="zjj close">
                    <img src="<?php echo goods_thum_images($v3['goods_id'],200,200); ?>">
                </div>
                <span class="similar-product-text"><?php echo $v3[goods_name]; ?></span>
                <span class="similar-product-price">
                    ¥<span class="big-price"><?php echo $v3[shop_price]; ?>元</span>
                    <span class="fr sg_g_time last_g_time" id="jstimerBox<?php echo $v3[goods_id]; ?>"></span>
                </span>
            </div>
        </a>
    </li>
<?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
    </div>
</div>

</div>
<script type="text/javascript" src="__STATIC__/js/sourch_submit.js"></script>
<script type="text/javascript">
    //加载更多商品
    /*var page = 0;
    function ajax_sourch_submit() {
        ++page;
        $.ajax({
            type: 'GET',
            url: "/index.php?m=Mobile&c=Index&is_ajax=1&a=_index_goods&p=" + page,
            success: function (data) {
                if (data) {
                    $(".likeshop > ul").append(data);
                    $('.get_more').hide();
                } else {
                    $('.get_more').hide();
                    $('#getmore').remove();
                }
            }
        })
    }
    ajax_sourch_submit();//调用加载更多
    //滚动加载更多
    $('.page-bd').scroll(function () {
        var scrollTop = $(this).scrollTop();
        var scrollHeight = $(document).height();
        var windowHeight = $(this).height();
        //console.log(scrollTop - (scrollHeight + windowHeight))
        if (scrollTop - (scrollHeight + windowHeight) > 50) {
            ajax_sourch_submit();//调用加载更多
        }
    });*/
</script>
<script src="__STATIC__/assets/js/lib/Swiper-3.4.2/swiper.jquery.min.js"></script>
<script>
    var swiper = new Swiper('.index-banner', {
        loop: true,
        autoplay: 1500,
        pagination: '.swiper-pagination',
        paginationClickable: true
    });
function countTime() {
        //获取当前时间
        var date = new Date();
        var now = date.getTime();
        //设置截止时间
        var str=$('#agentend_time0').val();//"2018/12/14 12:00:00";
        var endDate = new Date(str);
        var end = endDate.getTime();

        //时间差
        var leftTime = end-now;
        //定义变量 d,h,m,s保存倒计时的时间
        var d,h,m,s;
        if (leftTime>=0) {
            d = Math.floor(leftTime/1000/60/60/24);
            h = Math.floor(leftTime/1000/60/60%24);
            m = Math.floor(leftTime/1000/60%60);
            s = Math.floor(leftTime/1000%60);
        }else{
            return false;
        }
        //将0-9的数字前面加上0，例1变为01
        d = checkTime(d);
        h = checkTime(h);
        m = checkTime(m);
        s = checkTime(s);
        function checkTime(i){
            if (i<10) {
                i = "0"+i;
            }
            return i;
        }
        //将倒计时赋值到div中
        $("._d0").text(d+"天");
        $("._h0").text(h+":");
        $("._m0").text(m+":");
        $("._s0").text(s+"");
        //递归每秒调用countTime方法，显示动态时间效果
        setTimeout(countTime,1000);
        countTime2();
        countTime3();
        countTime4();
    }
function countTime2() {
        //获取当前时间
        var date = new Date();
        var now = date.getTime();
        //设置截止时间
        var str=$('#agentend_time1').val();//"2018/12/15 12:00:00";
        //console.log(str);
        var endDate = new Date(str);
        var end = endDate.getTime();

        //时间差
        var leftTime = end-now;
        //定义变量 d,h,m,s保存倒计时的时间
        var d,h,m,s;
        if (leftTime>=0) {
            d = Math.floor(leftTime/1000/60/60/24);
            h = Math.floor(leftTime/1000/60/60%24);
            m = Math.floor(leftTime/1000/60%60);
            s = Math.floor(leftTime/1000%60);
        }else{
            return false;
        }
        //将0-9的数字前面加上0，例1变为01
        d = checkTime(d);
        h = checkTime(h);
        m = checkTime(m);
        s = checkTime(s);
        function checkTime(i){
            if (i<10) {
                i = "0"+i;
            }
            return i;
        }
        //将倒计时赋值到div中
        $("._d1").text(d+"天");
        $("._h1").text(h+":");
        $("._m1").text(m+":");
        $("._s1").text(s+"");

        //递归每秒调用countTime方法，显示动态时间效果
        //setTimeout(countTime2,1000);

    }
    function countTime3() {
        //获取当前时间
        var date = new Date();
        var now = date.getTime();
        //设置截止时间
        var str=$('#agentend_time2').val();//"2018/12/15 12:00:00";
        //console.log(str);
        var endDate = new Date(str);
        var end = endDate.getTime();

        //时间差
        var leftTime = end-now;
        //定义变量 d,h,m,s保存倒计时的时间
        var d,h,m,s;
        if (leftTime>=0) {
            d = Math.floor(leftTime/1000/60/60/24);
            h = Math.floor(leftTime/1000/60/60%24);
            m = Math.floor(leftTime/1000/60%60);
            s = Math.floor(leftTime/1000%60);
        }else{
            return false;
        }
        //将0-9的数字前面加上0，例1变为01
        d = checkTime(d);
        h = checkTime(h);
        m = checkTime(m);
        s = checkTime(s);
        function checkTime(i){
            if (i<10) {
                i = "0"+i;
            }
            return i;
        }
        //将倒计时赋值到div中
        $("._d2").text(d+"天");
        $("._h2").text(h+":");
        $("._m2").text(m+":");
        $("._s2").text(s+"");

        //递归每秒调用countTime方法，显示动态时间效果
        //setTimeout(countTime2,1000);

    }
    function countTime4() {
        //获取当前时间
        var date = new Date();
        var now = date.getTime();
        //设置截止时间
        var str=$('#agentend_time3').val();//"2018/12/15 12:00:00";
        //console.log(str);
        var endDate = new Date(str);
        var end = endDate.getTime();

        //时间差
        var leftTime = end-now;
        //定义变量 d,h,m,s保存倒计时的时间
        var d,h,m,s;
        if (leftTime>=0) {
            d = Math.floor(leftTime/1000/60/60/24);
            h = Math.floor(leftTime/1000/60/60%24);
            m = Math.floor(leftTime/1000/60%60);
            s = Math.floor(leftTime/1000%60);
        }else{
            return false;
        }
        //将0-9的数字前面加上0，例1变为01
        d = checkTime(d);
        h = checkTime(h);
        m = checkTime(m);
        s = checkTime(s);
        function checkTime(i){
            if (i<10) {
                i = "0"+i;
            }
            return i;
        }
        //将倒计时赋值到div中
        $("._d3").text(d+"天");
        $("._h3").text(h+":");
        $("._m3").text(m+":");
        $("._s3").text(s+"");

        //递归每秒调用countTime方法，显示动态时间效果
        //setTimeout(countTime2,1000);

    }
</script>
<div class="bottom-tabbar">
    <a  <?php if(CONTROLLER_NAME == 'Index'): ?>class="bottom-tabbar__item @@item1 active " <?php else: ?>class="bottom-tabbar__item @@item1" <?php endif; ?> href="<?php echo U('Index/index'); ?>" >
    <span class="icon">
                        <img src="__STATIC__/assets/images/tabbar_icon01_lh.jpg"/>
            <img class="lhimg" src="__STATIC__/assets/images/tabbar_icon01.jpg"/>
        </span>
    <p class="label">首页</p>
    </a>
    <a href="<?php echo U('Goods/categoryList'); ?>" <?php if(CONTROLLER_NAME == 'Goods'): ?>class="bottom-tabbar__item @@item3 active"<?php else: ?>class="bottom-tabbar__item @@item3"<?php endif; ?> >
    <span class="icon">
            <img src="__STATIC__/assets/images/tabbar_icon03_lh.jpg"/>
            <img class="lhimg" src="__STATIC__/assets/images/bottom_icon03.jpg"/>
        </span>
    <p class="label">分类</p>
    </a>
    <a href="<?php echo U('Cart/index'); ?>"  <?php if(CONTROLLER_NAME == 'Cart'): ?>class="bottom-tabbar__item @@item2 active " <?php else: ?>class="bottom-tabbar__item @@item2"<?php endif; ?>>
    <span class="icon">
            <img src="__STATIC__/assets/images/tabbar_icon02_lh.jpg"/>
            <img class="lhimg" src="__STATIC__/assets/images/tabbar_icon02.jpg"/>
        </span>
    <p class="label">购物车</p>
    </a>

    <a href="<?php echo U('User/index'); ?>" <?php if(CONTROLLER_NAME == 'User'): ?>class="bottom-tabbar__item @@item4 active"<?php else: ?>class="bottom-tabbar__item @@item4"<?php endif; ?> >
    <span class="icon">
            <img src="__STATIC__/assets/images/tabbar_icon04_lh.jpg"/>
            <img class="lhimg" src="__STATIC__/assets/images/tabbar_icon04.jpg"/>
        </span>
    <p class="label">我的</p>
    </a>
</div>
</body>
</html>