<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:45:"./template/mobile/new/goods\categoryList.html";i:1551506935;s:44:"./template/mobile/new/common\layout_nav.html";i:1551506935;s:40:"./template/mobile/new/common\header.html";i:1551506935;s:44:"./template/mobile/new/common\footer_nav.html";i:1551506935;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=0">
    <link rel="stylesheet" type="text/css" href="__STATIC__/assets/weui/weui.css">
    <link rel="stylesheet" type="text/css" href="__STATIC__/assets/css/comm.css">
    <link rel="stylesheet" type="text/css" href="__STATIC__/assets/css/index.css">
    <link rel="stylesheet" type="text/css" href="__STATIC__/assets/js/lib/Swiper-3.4.2/swiper.min.css">
    <link rel="stylesheet" type="text/css" href="__STATIC__/assets/css/category.css">
    <script src="__STATIC__/assets/js/lib/jquery.min.2.1.3.js"></script>
    <script src="__STATIC__/assets/js/lib/weui.min.js"></script>
    <script src="__STATIC__/assets/js/comm.js"></script>
    <link rel="stylesheet" type="text/css" href="__STATIC__/assets/css/style.css">
    <script src="__PUBLIC__/js/global.js"></script>
    <script src="__STATIC__/js/layer.js"  type="text/javascript" ></script>
    <script src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>

    <script src="__STATIC__/assets/js/wxsdkcommon.js?v=1455"></script>

    <title><?php if($title): ?><?php echo $title; ?>--<?php endif; ?><?php echo $tpshop_config['shop_info_store_title']; ?></title>
</head>
<script>
    var appId = "<?php echo $signPackage['appId']; ?>";
    var timestamp = "<?php echo $signPackage['timestamp']; ?>";
    var nonceStr = "<?php echo $signPackage['nonceStr']; ?>";
    var signature = "<?php echo $signPackage['signature']; ?>";
</script>
<body class="[body]" <?php if(CONTROLLER_NAME == 'Index' and ACTION_NAME  == 'index'): ?> onload="countTime()" <?php endif; ?> >



<div class="page">
    <div class="page-hd">
        <div class="header">
            <div class="header-left">
                <a href="javascript:history.back(-1);" class="left-arrow"></a>
            </div>
            <div class="header-title">商品分类</div>
            <div class="header-right"><a href="#"></a> </div>
        </div>
    </div>
    <div class="page-bd vux-1px-t">
        <div class="category-left category1">
            <ul>
                <?php if(is_array($goods_category_tree) || $goods_category_tree instanceof \think\Collection || $goods_category_tree instanceof \think\Paginator): if( count($goods_category_tree)==0 ) : echo "" ;else: foreach($goods_category_tree as $k=>$vo): if($vo[level] == 1): ?>
                        <li>
                            <a href="javascript:void(0);" <?php if($m == 0): endif; ?> data-id="<?php echo $m++; ?>"><?php echo getSubstr($vo['mobile_name'],0,12); ?></a>
                        </li>
                    <?php endif; endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </div>
        <div class="category-right category2">

            <?php if(is_array($goods_category_tree) || $goods_category_tree instanceof \think\Collection || $goods_category_tree instanceof \think\Paginator): if( count($goods_category_tree)==0 ) : echo "" ;else: foreach($goods_category_tree as $kk=>$vo): ?>
                <div class="branchList" >
                    <div>
                        <a href="<?php echo U('Mobile/Goods/goodsList',array('id'=>$vo[id])); ?>" class="golist-btn">查看<?php echo $vo['mobile_name']; ?>类商品列表</a>
                    </div>
                <?php if(is_array($vo['tmenu']) || $vo['tmenu'] instanceof \think\Collection || $vo['tmenu'] instanceof \think\Paginator): if( count($vo['tmenu'])==0 ) : echo "" ;else: foreach($vo['tmenu'] as $k2=>$v2): ?>
                <!--<div class="divder">-->
                    <!--<span ><?php echo $v2['name']; ?></span>-->
                <!--</div>-->
                <ul class="goods-list">
                    <?php if(is_array($vo['tmenu']) || $vo['tmenu'] instanceof \think\Collection || $vo['tmenu'] instanceof \think\Paginator): if( count($vo['tmenu'])==0 ) : echo "" ;else: foreach($vo['tmenu'] as $key=>$v3): ?>
                    <li class="goods-list__item" style="text-align: center;line-height: 20px;">
                        <a href="<?php echo U('Mobile/Goods/goodsList',array('id'=>$v3[id])); ?>">
                        <img style="max-width:100%;line-height: 20px;overflow:hidden;" src="<?php echo (isset($v3['image']) && ($v3['image'] !== '')?$v3['image']:'__STATIC__/images/zy.png'); ?>"/>
                        <p><?php echo $v3['name']; ?></p>
                    </a></li>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </ul>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </div>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </div>
    </div>
</div>

<script>
    $(function () {
        //初始化
        $('.category1 li').eq(0).addClass('active');
        //点击切换2 3级分类
        var array=new Array();
        $('.category1 li').each(function(){
            array.push($(this).position().top-0);
        });
        $('.branchList').eq(0).show().siblings().hide();
        $('.category1 li').click(function() {
            var index = $(this).index() ;
            console.log(index)
            $('.category1').delay(200).animate({scrollTop:array[index]},300);
            $(this).addClass('active').siblings().removeClass();
            $('.branchList').eq(index).show().siblings().hide();
            $('.category2').scrollTop(0);
        });
    });
</script>

<div class="bottom-tabbar">
    <a  <?php if(CONTROLLER_NAME == 'Index'): ?>class="bottom-tabbar__item @@item1 active " <?php else: ?>class="bottom-tabbar__item @@item1" <?php endif; ?> href="<?php echo U('Index/index'); ?>" >
    <span class="icon">
                        <img src="__STATIC__/assets/images/tabbar_icon01_lh.jpg"/>
            <img class="lhimg" src="__STATIC__/assets/images/tabbar_icon01.jpg"/>
        </span>
    <p class="label">首页</p>
    </a>
    <a href="<?php echo U('Goods/categoryList'); ?>" <?php if(CONTROLLER_NAME == 'Goods'): ?>class="bottom-tabbar__item @@item3 active"<?php else: ?>class="bottom-tabbar__item @@item3"<?php endif; ?> >
    <span class="icon">
            <img src="__STATIC__/assets/images/tabbar_icon03_lh.jpg"/>
            <img class="lhimg" src="__STATIC__/assets/images/bottom_icon03.jpg"/>
        </span>
    <p class="label">分类</p>
    </a>
    <a href="<?php echo U('Cart/index'); ?>"  <?php if(CONTROLLER_NAME == 'Cart'): ?>class="bottom-tabbar__item @@item2 active " <?php else: ?>class="bottom-tabbar__item @@item2"<?php endif; ?>>
    <span class="icon">
            <img src="__STATIC__/assets/images/tabbar_icon02_lh.jpg"/>
            <img class="lhimg" src="__STATIC__/assets/images/tabbar_icon02.jpg"/>
        </span>
    <p class="label">购物车</p>
    </a>

    <a href="<?php echo U('User/index'); ?>" <?php if(CONTROLLER_NAME == 'User'): ?>class="bottom-tabbar__item @@item4 active"<?php else: ?>class="bottom-tabbar__item @@item4"<?php endif; ?> >
    <span class="icon">
            <img src="__STATIC__/assets/images/tabbar_icon04_lh.jpg"/>
            <img class="lhimg" src="__STATIC__/assets/images/tabbar_icon04.jpg"/>
        </span>
    <p class="label">我的</p>
    </a>
</div>
</body>
</html>